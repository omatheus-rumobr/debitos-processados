#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para criar o banco de dados SQLite3 com a modelagem completa
"""

import sqlite3
import os
from datetime import datetime

# Nome do arquivo do banco de dados
DB_NAME = 'meu_danfe.db'

def criar_banco():
    """Cria o banco de dados SQLite3 com todas as tabelas"""
    
    # Remove o banco existente se houver (opcional - comente se não quiser sobrescrever)
    if os.path.exists(DB_NAME):
        print(f"[AVISO] Banco {DB_NAME} ja existe. Removendo...")
        os.remove(DB_NAME)
    
    # Conecta ao banco (cria se não existir)
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    print(f"Criando banco de dados {DB_NAME}...")
    
    # 1. Tabela Usuarios
    print("  [OK] Criando tabela Usuarios...")
    cursor.execute('''
        CREATE TABLE Usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            ultimo_acesso DATETIME
        )
    ''')
    
    # 2. Tabela Status
    print("  [OK] Criando tabela Status...")
    cursor.execute('''
        CREATE TABLE Status (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL
        )
    ''')
    
    # 3. Tabela Fila
    print("  [OK] Criando tabela Fila...")
    cursor.execute('''
        CREATE TABLE Fila (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chave_nfe TEXT NOT NULL,
            tipo_chave_nfe TEXT NOT NULL,
            data_criacao DATETIME NOT NULL,
            usuario_id INTEGER NOT NULL,
            status_id INTEGER NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES Usuarios(id),
            FOREIGN KEY (status_id) REFERENCES Status(id)
        )
    ''')
    
    # 4. Tabela Arquivo
    print("  [OK] Criando tabela Arquivo...")
    cursor.execute('''
        CREATE TABLE Arquivo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fila_id INTEGER NOT NULL,
            caminho TEXT NOT NULL,
            FOREIGN KEY (fila_id) REFERENCES Fila(id)
        )
    ''')
    
    # 5. Tabela h_campos_template (Template de campos do usuário)
    print("  [OK] Criando tabela h_campos_template...")
    cursor.execute('''
        CREATE TABLE h_campos_template (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            nome TEXT NOT NULL,
            caminho_padrao TEXT NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES Usuarios(id)
        )
    ''')
    
    # 6. Tabela Fila_campos (Campos específicos de cada fila)
    print("  [OK] Criando tabela Fila_campos...")
    cursor.execute('''
        CREATE TABLE Fila_campos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fila_id INTEGER NOT NULL,
            nome TEXT NOT NULL,
            caminho TEXT NOT NULL,
            FOREIGN KEY (fila_id) REFERENCES Fila(id)
        )
    ''')
    
    # Inserir alguns status padrão (opcional, mas útil)
    print("  [OK] Inserindo status padrao...")
    status_padrao = [
        ('Pendente',),
        ('Processando',),
        ('Concluído',),
        ('Erro',),
    ]
    cursor.executemany('INSERT INTO Status (nome) VALUES (?)', status_padrao)
    
    # Salvar as alterações
    conn.commit()
    
    # Verificar as tabelas criadas
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tabelas = cursor.fetchall()
    
    print(f"\n[SUCESSO] Banco de dados criado com sucesso!")
    print(f"Tabelas criadas: {len(tabelas)}")
    for tabela in tabelas:
        print(f"   - {tabela[0]}")
    
    # Mostrar status inseridos
    cursor.execute("SELECT id, nome FROM Status")
    status = cursor.fetchall()
    print(f"\nStatus disponiveis:")
    for s in status:
        print(f"   - {s[0]}: {s[1]}")
    
    conn.close()
    print(f"\nBanco {DB_NAME} pronto para uso!")

if __name__ == '__main__':
    criar_banco()
