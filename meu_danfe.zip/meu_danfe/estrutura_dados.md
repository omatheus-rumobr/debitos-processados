# Modelagem de dados

## 🧑 Usuarios

```sql
Usuarios (
    id INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    ultimo_acesso DATETIME
)
```

---

## 📊 Status

```sql
Status (
    id INTEGER PRIMARY KEY,
    nome TEXT NOT NULL
)
```

---

## 📂 Fila

```sql
Fila (
    id INTEGER PRIMARY KEY,
    chave_nfe TEXT NOT NULL,
    tipo_chave_nfe TEXT NOT NULL,
    data_criacao DATETIME NOT NULL,
    usuario_id INTEGER NOT NULL,
    status_id INTEGER NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES Usuarios(id),
    FOREIGN KEY (status_id) REFERENCES Status(id)
)
```

---

## 📁 Arquivo

```sql
Arquivo (
    id INTEGER PRIMARY KEY,
    fila_id INTEGER NOT NULL,
    caminho TEXT NOT NULL,
    FOREIGN KEY (fila_id) REFERENCES Fila(id)
)
```

---

# 🧠 Histórico Padrão do Usuário (Template)

Agora ele vira um modelo base:

## 📝 h_campos_template

```sql
h_campos_template (
    id INTEGER PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    nome TEXT NOT NULL,
    caminho_padrao TEXT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES Usuarios(id)
)
```

---

# 🔥 Nova Tabela Essencial

Agora criamos os caminhos reais de cada fila:

## 📌 Fila_campos

Essa tabela guarda:

* A fila
* O nome do campo
* O caminho usado naquele registro específico

```sql
Fila_campos (
    id INTEGER PRIMARY KEY,
    fila_id INTEGER NOT NULL,
    nome TEXT NOT NULL,
    caminho TEXT NOT NULL,
    FOREIGN KEY (fila_id) REFERENCES Fila(id)
)
```

---

# 🎯 O Que Mudou na Prática?

Agora o fluxo é:

1. Usuário cria templates (`h_campos_template`)
2. Ao criar uma Fila:

   * O sistema copia os templates
   * Insere em `Fila_campos`
3. Cada Fila passa a ter seus próprios caminhos independentes

---
