from pathlib import Path
import xml.etree.ElementTree as ET
import json


def xml_to_dict(element):
    """
    Converte um elemento XML e seus filhos em um dicionário recursivo.
    Captura todas as chaves (tags) em todos os níveis de aninhamento.
    """
    result = {}
    
    # Adiciona atributos do elemento
    if element.attrib:
        result['@attributes'] = element.attrib
    
    # Adiciona o texto do elemento se existir e não for apenas espaços em branco
    text = element.text.strip() if element.text else None
    if text:
        result['@text'] = text
    
    # Processa os filhos recursivamente
    for child in element:
        tag = child.tag
        
        # Remove namespace se existir
        if '}' in tag:
            tag = tag.split('}')[1]
        
        # Se a tag já existe, converte em lista
        if tag in result:
            if not isinstance(result[tag], list):
                result[tag] = [result[tag]]
            result[tag].append(xml_to_dict(child))
        else:
            result[tag] = xml_to_dict(child)
    
    # Se não tem atributos, texto nem filhos, retorna apenas o texto ou None
    if not result and element.text:
        return element.text.strip() if element.text.strip() else None
    
    return result if result else None


def parse_xml_to_json(xml_path, json_path=None):
    """
    Lê um arquivo XML e converte para JSON com todas as chaves.
    
    Args:
        xml_path: Caminho para o arquivo XML
        json_path: Caminho para salvar o JSON (opcional)
    
    Returns:
        Dicionário com todos os dados do XML
    """
    xml_file = Path(xml_path)
    
    if not xml_file.exists():
        raise FileNotFoundError(f"Arquivo XML não encontrado: {xml_path}")
    
    # Parse do XML
    tree = ET.parse(xml_file)
    root = tree.getroot()
    
    # Converte para dicionário
    data = xml_to_dict(root)
    
    # Salva em JSON se o caminho foi fornecido
    if json_path:
        json_file = Path(json_path)
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"JSON salvo em: {json_path}")
    
    return data


if __name__ == "__main__":
    nfe_path = Path("NFE-52230514796754001267550100001976281000130429.xml")
    json_path = Path("nfe_data.json")
    
    try:
        data = parse_xml_to_json(nfe_path, json_path)
        print("XML parseado com sucesso!")
        print(f"Total de chaves principais: {len(data)}")
    except Exception as e:
        print(f"Erro ao processar XML: {e}")
