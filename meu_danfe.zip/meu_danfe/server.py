from flask import Flask, request, jsonify
from flasgger import Swagger
from loguru import logger
import os
import sqlite3
from datetime import datetime

# Configurar loguru
logger.add(
    "logs/app_{time}.log",
    rotation="500 MB",
    retention="10 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
    encoding="utf-8"
)

app = Flask(__name__)

# Configurar Swagger
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": "apispec",
            "route": "/apispec.json",
            "rule_filter": lambda rule: True,
            "model_filter": lambda tag: True,
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/swagger"
}

swagger_template = {
    "swagger": "2.0",
    "info": {
        "title": "API Meu DANFE",
        "description": "API para gerenciamento de DANFE e NFe",
        "version": "1.0.0"
    },
    "basePath": "/",
    "schemes": ["http", "https"]
}

swagger = Swagger(app, config=swagger_config, template=swagger_template)

# Configuração do banco de dados
DB_NAME = "meu_danfe.db"


def get_db_connection():
    """Cria e retorna uma conexão com o banco de dados"""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/health", methods=["GET"])
def health_check():
    """
    Endpoint para verificar a saúde da API
    ---
    tags:
      - Health
    responses:
      200:
        description: API está funcionando
        schema:
          type: object
          properties:
            status:
              type: string
              example: "ok"
            timestamp:
              type: string
              example: "2024-01-01T12:00:00"
    """
    logger.info("Health check solicitado")
    return jsonify({
        "status": "ok",
        "timestamp": datetime.now().isoformat()
    }), 200


@app.route("/login", methods=["POST"])
def login():
    """
    Endpoint para fazer login de um usuário
    ---
    tags:
      - Autenticação
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - nome
          properties:
            nome:
              type: string
              description: Nome do usuário
              example: "João Silva"
    responses:
      200:
        description: Login realizado com sucesso ou falha
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
            usuario_id:
              type: integer
            ultimo_acesso:
              type: string
      400:
        description: Nome de usuário não fornecido
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
      500:
        description: Erro interno do servidor
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    try:
        data = request.get_json()
        nome = data.get("nome")
        
        logger.info(f"Tentativa de login para usuário: {nome}")
        
        if not nome:
            logger.warning("Nome de usuário não fornecido")
            return jsonify({
                "success": False,
                "message": "Nome de usuário é obrigatório"
            }), 400
        
        # Conectar ao banco de dados
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verificar se o usuário existe
        cursor.execute("SELECT id, ultimo_acesso FROM Usuarios WHERE nome = ?", (nome,))
        usuario = cursor.fetchone()
        
        if not usuario:
            logger.warning(f"Usuário não encontrado: {nome}")
            conn.close()
            return jsonify({
                "success": False,
                "message": "Usuário não encontrado"
            }), 200
        
        # Atualizar o campo ultimo_acesso
        agora = datetime.now().isoformat()
        cursor.execute(
            "UPDATE Usuarios SET ultimo_acesso = ? WHERE id = ?",
            (agora, usuario["id"])
        )
        conn.commit()
        conn.close()
        
        logger.info(f"Login realizado com sucesso para usuário: {nome} (ID: {usuario['id']})")
        return jsonify({
            "success": True,
            "message": "Login realizado com sucesso",
            "usuario_id": usuario["id"],
            "ultimo_acesso": agora
        }), 200
        
    except sqlite3.Error as e:
        logger.error(f"Erro ao acessar banco de dados: {str(e)}")
        if 'conn' in locals():
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro ao acessar banco de dados: {str(e)}"
        }), 500
    except Exception as e:
        logger.error(f"Erro ao processar login: {str(e)}")
        if 'conn' in locals():
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.route("/nfe/buscar", methods=["POST"])
def buscar_nfe():
    """
    Endpoint para buscar uma NFe pela chave de acesso
    ---
    tags:
      - NFe
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - chave_nfe
          properties:
            chave_nfe:
              type: string
              description: Chave de acesso da NFe (44 dígitos)
              example: "43260177863223016020551200000346101721299920"
    responses:
      200:
        description: NFe encontrada com sucesso
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
            chave_nfe:
              type: string
            data:
              type: object
      400:
        description: Chave de acesso inválida
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    try:
        data = request.get_json()
        chave_nfe = data.get("chave_nfe")
        
        logger.info(f"Busca de NFe solicitada: {chave_nfe}")
        
        if not chave_nfe:
            logger.warning("Chave de NFe não fornecida")
            return jsonify({
                "success": False,
                "message": "Chave de NFe é obrigatória"
            }), 400
        
        if len(chave_nfe) != 44:
            logger.warning(f"Chave de NFe inválida (tamanho incorreto): {chave_nfe}")
            return jsonify({
                "success": False,
                "message": "Chave de NFe deve ter 44 dígitos"
            }), 400
        
        # Simulação de busca (aqui você integraria com sua lógica)
        logger.info(f"NFe encontrada: {chave_nfe}")
        return jsonify({
            "success": True,
            "message": "NFe encontrada com sucesso",
            "chave_nfe": chave_nfe,
            "data": {
                "status": "processada",
                "data_emissao": "2024-01-01",
                "valor": 1000.00
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao buscar NFe: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.route("/nfe/<string:chave>", methods=["GET"])
def obter_nfe(chave):
    """
    Endpoint para obter informações de uma NFe pela chave
    ---
    tags:
      - NFe
    parameters:
      - in: path
        name: chave
        type: string
        required: true
        description: Chave de acesso da NFe
        example: "43260177863223016020551200000346101721299920"
    responses:
      200:
        description: Informações da NFe
        schema:
          type: object
          properties:
            success:
              type: boolean
            chave:
              type: string
            informacoes:
              type: object
      404:
        description: NFe não encontrada
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    try:
        logger.info(f"Obter informações da NFe: {chave}")
        
        if len(chave) != 44:
            logger.warning(f"Chave de NFe inválida: {chave}")
            return jsonify({
                "success": False,
                "message": "Chave de NFe inválida"
            }), 400
        
        # Simulação de obtenção de dados
        logger.info(f"Informações da NFe {chave} retornadas com sucesso")
        return jsonify({
            "success": True,
            "chave": chave,
            "informacoes": {
                "numero": "123456",
                "serie": "1",
                "data_emissao": "2024-01-01T10:00:00",
                "emitente": "Empresa Exemplo LTDA",
                "destinatario": "Cliente Exemplo",
                "valor_total": 1000.00,
                "status": "autorizada"
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao obter NFe {chave}: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.route("/nfe/download", methods=["POST"])
def download_xml():
    """
    Endpoint para baixar o XML de uma NFe
    ---
    tags:
      - NFe
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - chave_nfe
          properties:
            chave_nfe:
              type: string
              description: Chave de acesso da NFe
              example: "43260177863223016020551200000346101721299920"
            formato:
              type: string
              description: Formato do download (xml ou pdf)
              example: "xml"
              enum: [xml, pdf]
    responses:
      200:
        description: Download iniciado com sucesso
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
            chave_nfe:
              type: string
            formato:
              type: string
            arquivo:
              type: string
      400:
        description: Parâmetros inválidos
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    try:
        data = request.get_json()
        chave_nfe = data.get("chave_nfe")
        formato = data.get("formato", "xml")
        
        logger.info(f"Download solicitado - NFe: {chave_nfe}, Formato: {formato}")
        
        if not chave_nfe:
            logger.warning("Chave de NFe não fornecida para download")
            return jsonify({
                "success": False,
                "message": "Chave de NFe é obrigatória"
            }), 400
        
        if formato not in ["xml", "pdf"]:
            logger.warning(f"Formato inválido: {formato}")
            return jsonify({
                "success": False,
                "message": "Formato deve ser 'xml' ou 'pdf'"
            }), 400
        
        # Simulação de download (aqui você integraria com sua lógica de download)
        nome_arquivo = f"{chave_nfe}.{formato}"
        logger.info(f"Download iniciado: {nome_arquivo}")
        
        return jsonify({
            "success": True,
            "message": f"Download do {formato.upper()} iniciado com sucesso",
            "chave_nfe": chave_nfe,
            "formato": formato,
            "arquivo": nome_arquivo
        }), 200
        
    except Exception as e:
        logger.error(f"Erro ao processar download: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.route("/fila/adicionar", methods=["POST"])
def adicionar_fila():
    """
    Endpoint para adicionar um item na fila de processamento
    ---
    tags:
      - Fila
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - usuario_id
            - chave_nfe
            - caminhos
          properties:
            usuario_id:
              type: integer
              description: ID do usuário que está solicitando
              example: 1
            chave_nfe:
              type: string
              description: Chave de acesso da NFe (44 dígitos)
              example: "43260177863223016020551200000346101721299920"
            tipo_chave_nfe:
              type: string
              description: Tipo da chave NFe (opcional, padrão NFe)
              example: "NFe"
            caminhos:
              type: array
              description: Lista de caminhos com nome e caminho
              items:
                type: object
                properties:
                  nome:
                    type: string
                    description: Nome do campo
                    example: "xml_download"
                  caminho:
                    type: string
                    description: Caminho do arquivo
                    example: "/caminho/para/arquivo.xml"
    responses:
      201:
        description: Item adicionado à fila com sucesso
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
            fila_id:
              type: integer
            dados:
              type: object
      400:
        description: Dados inválidos
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
      404:
        description: Usuário não encontrado
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
      500:
        description: Erro interno do servidor
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    conn = None
    try:
        data = request.get_json()
        usuario_id = data.get("usuario_id")
        chave_nfe = data.get("chave_nfe")
        tipo_chave_nfe = data.get("tipo_chave_nfe", "NFe")
        caminhos = data.get("caminhos", [])
        
        logger.info(f"Tentativa de adicionar item na fila - Usuário ID: {usuario_id}, Chave NFe: {chave_nfe}")
        
        # Validação: usuario_id
        if usuario_id is None:
            logger.warning("ID do usuário não fornecido")
            return jsonify({
                "success": False,
                "message": "ID do usuário é obrigatório"
            }), 400
        
        if not isinstance(usuario_id, int) or usuario_id <= 0:
            logger.warning(f"ID do usuário inválido: {usuario_id}")
            return jsonify({
                "success": False,
                "message": "ID do usuário deve ser um número inteiro positivo"
            }), 400
        
        # Validação: chave_nfe
        if not chave_nfe:
            logger.warning("Chave de NFe não fornecida")
            return jsonify({
                "success": False,
                "message": "Chave de NFe é obrigatória"
            }), 400
        
        if len(chave_nfe) != 44:
            logger.warning(f"Chave de NFe inválida (tamanho incorreto): {chave_nfe}")
            return jsonify({
                "success": False,
                "message": "Chave de NFe deve ter 44 dígitos"
            }), 400
        
        # Validação: caminhos
        if not isinstance(caminhos, list):
            logger.warning("Lista de caminhos não é um array")
            return jsonify({
                "success": False,
                "message": "Caminhos deve ser uma lista"
            }), 400
        
        if len(caminhos) == 0:
            logger.warning("Lista de caminhos está vazia")
            return jsonify({
                "success": False,
                "message": "É necessário fornecer pelo menos um caminho"
            }), 400
        
        # Validar estrutura dos caminhos
        for idx, caminho_item in enumerate(caminhos):
            if not isinstance(caminho_item, dict):
                logger.warning(f"Caminho no índice {idx} não é um objeto válido")
                return jsonify({
                    "success": False,
                    "message": f"Caminho no índice {idx} deve ser um objeto com 'nome' e 'caminho'"
                }), 400
            
            if "nome" not in caminho_item or "caminho" not in caminho_item:
                logger.warning(f"Caminho no índice {idx} não possui 'nome' ou 'caminho'")
                return jsonify({
                    "success": False,
                    "message": f"Caminho no índice {idx} deve conter 'nome' e 'caminho'"
                }), 400
            
            if not caminho_item["nome"] or not caminho_item["caminho"]:
                logger.warning(f"Caminho no índice {idx} possui 'nome' ou 'caminho' vazio")
                return jsonify({
                    "success": False,
                    "message": f"Caminho no índice {idx} não pode ter 'nome' ou 'caminho' vazios"
                }), 400
        
        # Conectar ao banco de dados
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Validar se o usuário existe
        cursor.execute("SELECT id, nome FROM Usuarios WHERE id = ?", (usuario_id,))
        usuario = cursor.fetchone()
        
        if not usuario:
            logger.warning(f"Usuário não encontrado: ID {usuario_id}")
            conn.close()
            return jsonify({
                "success": False,
                "message": f"Usuário com ID {usuario_id} não encontrado"
            }), 404
        
        # Obter o status "Pendente" (id = 1 conforme criar_banco.py)
        cursor.execute("SELECT id FROM Status WHERE id = 1")
        status = cursor.fetchone()
        
        if not status:
            logger.error("Status 'Pendente' não encontrado no banco de dados")
            conn.close()
            return jsonify({
                "success": False,
                "message": "Erro de configuração: Status 'Pendente' não encontrado"
            }), 500
        
        status_id = status["id"]
        
        # Inserir na tabela Fila
        data_criacao = datetime.now().isoformat()
        cursor.execute(
            """INSERT INTO Fila (chave_nfe, tipo_chave_nfe, data_criacao, usuario_id, status_id)
               VALUES (?, ?, ?, ?, ?)""",
            (chave_nfe, tipo_chave_nfe, data_criacao, usuario_id, status_id)
        )
        fila_id = cursor.lastrowid
        
        logger.info(f"Registro criado na Fila com ID: {fila_id}")
        
        # Inserir os caminhos na tabela Fila_campos
        caminhos_inseridos = []
        for caminho_item in caminhos:
            cursor.execute(
                """INSERT INTO Fila_campos (fila_id, nome, caminho)
                   VALUES (?, ?, ?)""",
                (fila_id, caminho_item["nome"], caminho_item["caminho"])
            )
            caminhos_inseridos.append({
                "nome": caminho_item["nome"],
                "caminho": caminho_item["caminho"]
            })
        
        # Commit das alterações
        conn.commit()
        conn.close()
        
        logger.info(f"Item adicionado à fila com sucesso - Fila ID: {fila_id}, Caminhos: {len(caminhos_inseridos)}")
        
        return jsonify({
            "success": True,
            "message": "Item adicionado à fila com sucesso",
            "fila_id": fila_id,
            "dados": {
                "chave_nfe": chave_nfe,
                "tipo_chave_nfe": tipo_chave_nfe,
                "usuario_id": usuario_id,
                "usuario_nome": usuario["nome"],
                "status_id": status_id,
                "data_criacao": data_criacao,
                "caminhos": caminhos_inseridos
            }
        }), 201
        
    except sqlite3.Error as e:
        logger.error(f"Erro ao acessar banco de dados: {str(e)}")
        if conn:
            conn.rollback()
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro ao acessar banco de dados: {str(e)}"
        }), 500
    except Exception as e:
        logger.error(f"Erro ao adicionar item na fila: {str(e)}")
        if conn:
            conn.rollback()
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.route("/fila/pendente", methods=["GET"])
def obter_fila_pendente():
    """
    Endpoint para obter um registro da fila com status pendente
    ---
    tags:
      - Fila
    responses:
      200:
        description: Registro pendente encontrado
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
            dados:
              type: object
              properties:
                fila_id:
                  type: integer
                chave_nfe:
                  type: string
                tipo_chave_nfe:
                  type: string
                data_criacao:
                  type: string
                usuario:
                  type: object
                  properties:
                    id:
                      type: integer
                    nome:
                      type: string
                status:
                  type: object
                  properties:
                    id:
                      type: integer
                    nome:
                      type: string
                caminhos:
                  type: array
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                      nome:
                        type: string
                      caminho:
                        type: string
      404:
        description: Nenhum registro pendente encontrado
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
      500:
        description: Erro interno do servidor
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    conn = None
    try:
        logger.info("Buscando registro pendente na fila")
        
        # Conectar ao banco de dados
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Buscar um registro pendente (status_id = 1)
        # Ordenar por data_criacao para pegar o mais antigo primeiro
        cursor.execute("""
            SELECT 
                f.id,
                f.chave_nfe,
                f.tipo_chave_nfe,
                f.data_criacao,
                f.usuario_id,
                f.status_id,
                u.nome as usuario_nome,
                s.nome as status_nome
            FROM Fila f
            INNER JOIN Usuarios u ON f.usuario_id = u.id
            INNER JOIN Status s ON f.status_id = s.id
            WHERE f.status_id = 1
            ORDER BY f.data_criacao ASC
            LIMIT 1
        """)
        
        fila = cursor.fetchone()
        
        if not fila:
            logger.info("Nenhum registro pendente encontrado na fila")
            conn.close()
            return jsonify({
                "success": False,
                "message": "Nenhum registro pendente encontrado na fila"
            }), 404
        
        # Buscar os caminhos relacionados
        cursor.execute("""
            SELECT id, nome, caminho
            FROM Fila_campos
            WHERE fila_id = ?
            ORDER BY id ASC
        """, (fila["id"],))
        
        caminhos = cursor.fetchall()
        
        # Converter caminhos para lista de dicionários
        caminhos_list = []
        for caminho in caminhos:
            caminhos_list.append({
                "id": caminho["id"],
                "nome": caminho["nome"],
                "caminho": caminho["caminho"]
            })
        
        conn.close()
        
        logger.info(f"Registro pendente encontrado - Fila ID: {fila['id']}, Chave NFe: {fila['chave_nfe']}")
        
        return jsonify({
            "success": True,
            "message": "Registro pendente encontrado",
            "dados": {
                "fila_id": fila["id"],
                "chave_nfe": fila["chave_nfe"],
                "tipo_chave_nfe": fila["tipo_chave_nfe"],
                "data_criacao": fila["data_criacao"],
                "usuario": {
                    "id": fila["usuario_id"],
                    "nome": fila["usuario_nome"]
                },
                "status": {
                    "id": fila["status_id"],
                    "nome": fila["status_nome"]
                },
                "caminhos": caminhos_list
            }
        }), 200
        
    except sqlite3.Error as e:
        logger.error(f"Erro ao acessar banco de dados: {str(e)}")
        if conn:
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro ao acessar banco de dados: {str(e)}"
        }), 500
    except Exception as e:
        logger.error(f"Erro ao obter registro pendente: {str(e)}")
        if conn:
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.route("/fila/<int:fila_id>/status", methods=["PUT"])
def atualizar_status_fila(fila_id):
    """
    Endpoint para atualizar o status de um registro da fila
    ---
    tags:
      - Fila
    parameters:
      - in: path
        name: fila_id
        type: integer
        required: true
        description: ID do registro na fila
        example: 1
      - in: body
        name: body
        required: true
        schema:
          type: object
          required:
            - status_id
          properties:
            status_id:
              type: integer
              description: ID do novo status
              example: 2
    responses:
      200:
        description: Status atualizado com sucesso
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
            dados:
              type: object
              properties:
                fila_id:
                  type: integer
                status_anterior:
                  type: object
                status_novo:
                  type: object
      400:
        description: Dados inválidos
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
      404:
        description: Registro ou status não encontrado
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
      500:
        description: Erro interno do servidor
        schema:
          type: object
          properties:
            success:
              type: boolean
            message:
              type: string
    """
    conn = None
    try:
        data = request.get_json()
        novo_status_id = data.get("status_id")
        
        logger.info(f"Tentativa de atualizar status da fila ID: {fila_id} para status_id: {novo_status_id}")
        
        # Validação: status_id
        if novo_status_id is None:
            logger.warning("ID do status não fornecido")
            return jsonify({
                "success": False,
                "message": "ID do status é obrigatório"
            }), 400
        
        if not isinstance(novo_status_id, int) or novo_status_id <= 0:
            logger.warning(f"ID do status inválido: {novo_status_id}")
            return jsonify({
                "success": False,
                "message": "ID do status deve ser um número inteiro positivo"
            }), 400
        
        # Validação: fila_id
        if fila_id <= 0:
            logger.warning(f"ID da fila inválido: {fila_id}")
            return jsonify({
                "success": False,
                "message": "ID da fila deve ser um número inteiro positivo"
            }), 400
        
        # Conectar ao banco de dados
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verificar se o registro da fila existe e obter o status atual
        cursor.execute("""
            SELECT 
                f.id,
                f.status_id,
                s.nome as status_nome
            FROM Fila f
            INNER JOIN Status s ON f.status_id = s.id
            WHERE f.id = ?
        """, (fila_id,))
        
        fila = cursor.fetchone()
        
        if not fila:
            logger.warning(f"Registro da fila não encontrado: ID {fila_id}")
            conn.close()
            return jsonify({
                "success": False,
                "message": f"Registro da fila com ID {fila_id} não encontrado"
            }), 404
        
        status_anterior_id = fila["status_id"]
        status_anterior_nome = fila["status_nome"]
        
        # Verificar se o novo status existe
        cursor.execute("SELECT id, nome FROM Status WHERE id = ?", (novo_status_id,))
        novo_status = cursor.fetchone()
        
        if not novo_status:
            logger.warning(f"Status não encontrado: ID {novo_status_id}")
            conn.close()
            return jsonify({
                "success": False,
                "message": f"Status com ID {novo_status_id} não encontrado"
            }), 404
        
        # Verificar se o status já é o mesmo
        if status_anterior_id == novo_status_id:
            logger.info(f"Status já está definido como {novo_status['nome']} para a fila ID {fila_id}")
            conn.close()
            return jsonify({
                "success": True,
                "message": f"Status já está definido como {novo_status['nome']}",
                "dados": {
                    "fila_id": fila_id,
                    "status_anterior": {
                        "id": status_anterior_id,
                        "nome": status_anterior_nome
                    },
                    "status_novo": {
                        "id": novo_status["id"],
                        "nome": novo_status["nome"]
                    }
                }
            }), 200
        
        # Atualizar o status
        cursor.execute(
            "UPDATE Fila SET status_id = ? WHERE id = ?",
            (novo_status_id, fila_id)
        )
        
        # Commit das alterações
        conn.commit()
        conn.close()
        
        logger.info(f"Status da fila ID {fila_id} atualizado de '{status_anterior_nome}' para '{novo_status['nome']}'")
        
        return jsonify({
            "success": True,
            "message": "Status atualizado com sucesso",
            "dados": {
                "fila_id": fila_id,
                "status_anterior": {
                    "id": status_anterior_id,
                    "nome": status_anterior_nome
                },
                "status_novo": {
                    "id": novo_status["id"],
                    "nome": novo_status["nome"]
                }
            }
        }), 200
        
    except sqlite3.Error as e:
        logger.error(f"Erro ao acessar banco de dados: {str(e)}")
        if conn:
            conn.rollback()
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro ao acessar banco de dados: {str(e)}"
        }), 500
    except Exception as e:
        logger.error(f"Erro ao atualizar status da fila: {str(e)}")
        if conn:
            conn.rollback()
            conn.close()
        return jsonify({
            "success": False,
            "message": f"Erro interno: {str(e)}"
        }), 500


@app.errorhandler(404)
def not_found(error):
    """Handler para rotas não encontradas"""
    logger.warning(f"Rota não encontrada: {request.path}")
    return jsonify({
        "success": False,
        "message": "Rota não encontrada"
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """Handler para erros internos"""
    logger.error(f"Erro interno: {str(error)}")
    return jsonify({
        "success": False,
        "message": "Erro interno do servidor"
    }), 500


if __name__ == "__main__":
    # Criar diretório de logs se não existir
    os.makedirs("logs", exist_ok=True)
    
    logger.info("Iniciando servidor Flask...")
    app.run(debug=True, host="0.0.0.0", port=5000)
