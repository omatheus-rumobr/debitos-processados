import undetected_chromedriver as uc
import time
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

URL = "https://meudanfe.com.br/#"
chave_nfe = "43260177863223016020551200000346101721299920"

# Configurar diretório de download
download_dir = os.getcwd()

# Configurar opções do Chrome para download
options = uc.ChromeOptions()
prefs = {
    "download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True
}
options.add_experimental_option("prefs", prefs)

# Criar e configurar o driver
driver = uc.Chrome(options=options)

try:
    # Abrir a URL
    driver.get(URL)
    
    # Esperar 5 segundos
    time.sleep(5)
    
    # Buscar o input e digitar a chave
    wait = WebDriverWait(driver, 10)
    input_element = wait.until(EC.presence_of_element_located((By.ID, "searchTxt")))
    input_element.clear()
    input_element.send_keys(chave_nfe)
    
    time.sleep(5)
    
    # Clicar no botão de buscar
    search_button = wait.until(EC.element_to_be_clickable((By.ID, "searchBtn")))
    search_button.click()
    
    time.sleep(10)
    
    # Clicar no botão de baixar XML
    download_button = wait.until(EC.element_to_be_clickable((By.ID, "downloadXmlBtn")))
    download_button.click()
    
    # Aguardar o download ser concluído
    time.sleep(5)
    
    # Recarregar a página
    driver.refresh()
    
    time.sleep(5)
    
finally:
    # Fechar o navegador
    driver.quit()
