# Documentação do Sistema de Processamento PJ Simples

## Visão Geral

Este sistema processa dados do Simples Nacional da Receita Federal, realizando exportações, cruzamentos, filtragens e atualizações em banco de dados. O processo é dividido em 13 passos sequenciais que transformam dados brutos em informações estruturadas e atualizadas.

## Fluxo Principal

```mermaid
flowchart TD
    Start([Início]) --> P1[Passo 1: Exportar CNPJ_RAIZ<br/>base_simples_periodos]
    P1 --> P2[Passo 2: Exportar CNPJ_RAIZ<br/>base_simples]
    P2 --> P3[Passo 3: Download<br/>Simples.zip]
    P3 --> P4[Passo 4: Extrair ZIP]
    P4 --> P5[Passo 5: Cruzamento<br/>de Dados]
    P5 --> P6[Passo 6: Separação<br/>por Ano]
    P6 --> P7[Passo 7: Processamento<br/>e Unificação]
    P7 --> P8[Passo 8: Remoção<br/>de Duplicados]
    P8 --> P9[Passo 9: Divisão por Ano<br/>campo saida]
    P9 --> P10[Passo 10: Filtragem<br/>Não Correspondentes]
    P10 --> P11[Passo 11: Encontrar<br/>Correspondentes]
    P11 --> P12[Passo 12: Atualizar<br/>dt_consulta]
    P12 --> P13[Passo 13: Inserir<br/>base_simples_periodos]
    P13 --> End([Fim])
    
    P1 -.->|Parquet| DB1[(exportados/)]
    P2 -.->|Parquet| DB2[(exportados_base_simples/)]
    P3 -.->|Download| ZIP[Simples-YYYY-MM.zip]
    P4 -.->|Extração| TEMP[(temp/)]
    P5 -.->|Resultado| NC[nao_correspondentes.parquet]
    P6 -.->|Por Ano| DADOS[dados_YYYY.parquet]
    P7 -.->|Unificado| TU[tabela_unificada.parquet]
    P8 -.->|Sem Dups| TSD[todos_dados_sem_duplicacoes.parquet]
    P9 -.->|Por Ano| AND[apenas_nao_duplicados_YYYY.parquet]
    P10 -.->|Filtrado| NCF[nao_correspondentes_filtrado.parquet]
    P11 -.->|Correspondentes| CE[correspondentes_encontrados.parquet]
    P12 -.->|Atualização| DB[(base_simples)]
    P13 -.->|Inserção| DB3[(base_simples_periodos)]
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style P1 fill:#87CEEB
    style P2 fill:#87CEEB
    style P3 fill:#FFB6C1
    style P4 fill:#FFB6C1
    style P5 fill:#DDA0DD
    style P6 fill:#DDA0DD
    style P7 fill:#F0E68C
    style P8 fill:#F0E68C
    style P9 fill:#98D8C8
    style P10 fill:#98D8C8
    style P11 fill:#FFA07A
    style P12 fill:#FFA07A
    style P13 fill:#B19CD9
```

## Arquitetura de Dados

```mermaid
erDiagram
    BASE_SIMPLES_PERIODOS ||--o{ EXPORTADOS : "exporta"
    BASE_SIMPLES ||--o{ EXPORTADOS_BASE_SIMPLES : "exporta"
    RECEITA_FEDERAL ||--|| SIMPLES_ZIP : "fornece"
    SIMPLES_ZIP ||--|| TEMP : "extrai"
    EXPORTADOS ||--o{ CRUZAMENTO : "usa"
    TEMP ||--|| CRUZAMENTO : "usa"
    CRUZAMENTO ||--|| NAO_CORRESPONDENTES : "gera"
    NAO_CORRESPONDENTES ||--o{ DADOS_YYYY : "separa"
    DADOS_YYYY ||--|| TABELA_UNIFICADA : "unifica"
    TABELA_UNIFICADA ||--|| TODOS_DADOS_SEM_DUPS : "remove dups"
    TODOS_DADOS_SEM_DUPS ||--o{ APENAS_NAO_DUPS_YYYY : "divide"
    NAO_CORRESPONDENTES ||--|| NAO_CORRESPONDENTES_FILTRADO : "filtra"
    NAO_CORRESPONDENTES_FILTRADO ||--|| CORRESPONDENTES_ENCONTRADOS : "cruza"
    EXPORTADOS_BASE_SIMPLES ||--|| CORRESPONDENTES_ENCONTRADOS : "cruza"
    CORRESPONDENTES_ENCONTRADOS ||--|| BASE_SIMPLES : "atualiza"
    APENAS_NAO_DUPS_YYYY ||--|| BASE_SIMPLES_PERIODOS : "insere"
    
    BASE_SIMPLES_PERIODOS {
        int id PK
        string cnpj_raiz
        date entrada
        date saida
        string motivo
    }
    BASE_SIMPLES {
        int id PK
        string cnpj_raiz
        date dt_consulta
    }
    EXPORTADOS {
        string cnpj_raiz
    }
    EXPORTADOS_BASE_SIMPLES {
        string cnpj_raiz
    }
    NAO_CORRESPONDENTES {
        string f0
        string f1
        int f2
        int f3
    }
```

---

## Estrutura dos Arquivos Fonte

### Arquivo Simples-YYYY-MM.zip

O arquivo ZIP é baixado da Receita Federal e contém dados do Simples Nacional para o período especificado.

**Estrutura do ZIP:**
```
Simples-YYYY-MM.zip
└── F.K03200$W.SIMPLES.CSV.D30513
    (ou nome similar, varia conforme o período)
```

**Características:**
- Formato: ZIP padrão
- Conteúdo: Arquivo CSV único
- Tamanho: Variável (geralmente centenas de MB a alguns GB)
- Codificação: UTF-8 ou similar
- Delimitador: Ponto e vírgula (`;`)

### Arquivo CSV: F.K03200$W.SIMPLES.CSV.D30513

O arquivo CSV dentro do ZIP contém dados das empresas do Simples Nacional.

**Estrutura do CSV:**

O arquivo **não possui cabeçalho** e contém as seguintes colunas (em ordem):

| Índice | Nome Padrão | Tipo | Descrição | Formato |
|--------|-------------|------|-----------|---------|
| 0 | `f0` | String | CNPJ Raiz | 8 dígitos (preserva zeros à esquerda) |
| 1 | `f1` | String | Motivo | 'N' ou 'S' |
| 2 | `f2` | Integer | Data de Entrada | YYYYMMDD (ex: 20230115) |
| 3 | `f3` | Integer | Data de Saída | YYYYMMDD (ex: 20231231) |

**Exemplo de Linha:**
```
12345678;N;20230115;20231231
```

**Descrição das Colunas:**

1. **CNPJ Raiz (f0)**: 
   - 8 primeiros dígitos do CNPJ
   - Deve ser tratado como string para preservar zeros à esquerda
   - Exemplo: `01234567` (não `1234567`)

2. **Motivo (f1)**:
   - `'N'` = Excluído do Simples Nacional
   - `'S'` = Optante pelo Simples Nacional

3. **Data de Entrada (f2)**:
   - Data no formato YYYYMMDD (ano, mês, dia)
   - Tipo: Integer
   - Exemplo: `20230115` = 15/01/2023

4. **Data de Saída (f3)**:
   - Data no formato YYYYMMDD (ano, mês, dia)
   - Tipo: Integer
   - Exemplo: `20231231` = 31/12/2023

**Características Importantes:**
- Delimitador: Ponto e vírgula (`;`)
- Sem cabeçalho: Primeira linha já contém dados
- Codificação: UTF-8 ou similar
- Preservação de zeros: CNPJ raiz deve ser tratado como string
- Valores nulos: Podem aparecer como vazios ou zeros

---

## Script Principal (main.py)

O arquivo `main.py` é o orquestrador principal que executa todos os 13 passos em sequência.

**Funcionalidades:**

1. **Execução Sequencial**: Executa os passos na ordem definida, interrompendo se algum passo falhar
2. **Configuração de Período**: Permite especificar o período (YYYY-MM) via argumento de linha de comando
3. **Logging Unificado**: Configura o logger loguru para todos os passos
4. **Tratamento de Erros**: Captura exceções e interrompe o fluxo em caso de erro crítico
5. **Resumo de Execução**: Exibe resumo final com status de cada passo executado

**Estrutura:**

```python
# Lista de passos a serem executados
passos = [
    ("Passo 1 - ...", lambda: executar_primeiro_passo(script_dir)),
    ("Passo 2 - ...", lambda: executar_segundo_passo(script_dir)),
    # ... todos os 13 passos
]
```

**Características:**
- Cada passo retorna `True` (sucesso) ou `False` (falha)
- Se um passo falhar, a execução é interrompida
- Resumo final mostra o status de cada passo
- Suporta argumentos de linha de comando para período

---

## Documentação dos Passos

### Passo 1: Exportação CNPJ_RAIZ - BASE_SIMPLES_PERIODOS

**Arquivo:** `primeiro_passo.py`

**Descrição:** Exporta a coluna `cnpj_raiz` da tabela `base_simples_periodos` para arquivos Parquet em lotes de 1 milhão de registros.

**Fluxo:**

```mermaid
flowchart LR
    Start([Início]) --> Check{Arquivos<br/>existem?}
    Check -->|Sim| Skip[Pular Exportação]
    Check -->|Não| Connect[Conectar ao<br/>PostgreSQL]
    Connect --> Count[Contar Registros]
    Count --> Loop[Processar em Lotes<br/>1M registros]
    Loop --> Read[Ler Lote do BD]
    Read --> Convert[Converter para<br/>PyArrow Table]
    Convert --> Save[Salvar Parquet<br/>cnpj_raiz_lote_NNNN.parquet]
    Save --> More{Mais<br/>lotes?}
    More -->|Sim| Loop
    More -->|Não| End([Fim])
    Skip --> End
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Check fill:#FFD700
    style Skip fill:#FFB6C1
```

**Entradas:**
- Banco de dados PostgreSQL (`base_simples_periodos`)
- Tabela: `base_simples_periodos`
- Coluna: `cnpj_raiz`

**Saídas:**
- Diretório: `exportados/`
- Arquivos: `cnpj_raiz_lote_0001.parquet`, `cnpj_raiz_lote_0002.parquet`, ...

**Características:**
- Processamento em lotes de 1 milhão de registros
- Compressão Snappy
- Validação de arquivos existentes (não sobrescreve)

---

### Passo 2: Exportação CNPJ_RAIZ - BASE_SIMPLES

**Arquivo:** `segundo_passo.py`

**Descrição:** Exporta a coluna `cnpj_raiz` da tabela `base_simples` para arquivos Parquet em lotes de 1 milhão de registros.

**Fluxo:**

```mermaid
flowchart LR
    Start([Início]) --> Check{Arquivos<br/>existem?}
    Check -->|Sim| Skip[Pular Exportação]
    Check -->|Não| Connect[Conectar ao<br/>PostgreSQL]
    Connect --> Count[Contar Registros]
    Count --> Loop[Processar em Lotes<br/>1M registros]
    Loop --> Read[Ler Lote do BD]
    Read --> Convert[Converter para<br/>PyArrow Table]
    Convert --> Save[Salvar Parquet<br/>base_simples_cnpj_raiz_lote_NNNN.parquet]
    Save --> More{Mais<br/>lotes?}
    More -->|Sim| Loop
    More -->|Não| End([Fim])
    Skip --> End
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Check fill:#FFD700
    style Skip fill:#FFB6C1
```

**Entradas:**
- Banco de dados PostgreSQL (`base_simples`)
- Tabela: `base_simples`
- Coluna: `cnpj_raiz`

**Saídas:**
- Diretório: `exportados_base_simples/`
- Arquivos: `base_simples_cnpj_raiz_lote_0001.parquet`, `base_simples_cnpj_raiz_lote_0002.parquet`, ...

**Características:**
- Mesma estrutura do Passo 1, mas para tabela diferente
- Processamento em lotes de 1 milhão de registros
- Compressão Snappy

---

### Passo 3: Download do Arquivo Simples.zip

**Arquivo:** `terceiro_passo.py`

**Descrição:** Baixa o arquivo `Simples.zip` da Receita Federal para o período especificado.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Periodo{Período<br/>especificado?}
    Periodo -->|Não| Now[Usar Período Atual<br/>YYYY-MM]
    Periodo -->|Sim| Use[Usar Período<br/>Informado]
    Now --> Check{Arquivo<br/>existe?}
    Use --> Check
    Check -->|Sim| Skip[Pular Download<br/>Arquivo já existe]
    Check -->|Não| Build[Construir URL<br/>Receita Federal]
    Build --> Download[Download com<br/>Retry 3x]
    Download --> Validate[Validar ZIP]
    Validate -->|Inválido| Retry{Tentativas<br/>< 3?}
    Retry -->|Sim| Download
    Retry -->|Não| Error[Erro]
    Validate -->|Válido| Success[Sucesso]
    Skip --> End([Fim])
    Success --> End
    Error --> End
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Check fill:#FFD700
    style Skip fill:#FFB6C1
    style Error fill:#FF6B6B
    style Success fill:#51CF66
```

**Entradas:**
- Período no formato YYYY-MM (opcional, padrão: período atual)
- URL base: `https://arquivos.receitafederal.gov.br/index.php/s/YggdBLfdninEJX9/download?path=/{periodo}/Simples.zip`

**Saídas:**
- Arquivo: `Simples-{periodo}.zip`

**Características:**
- Retry automático (3 tentativas)
- Validação de integridade do ZIP
- Barra de progresso durante download
- Não sobrescreve arquivos existentes

---

### Passo 4: Extração do Arquivo ZIP

**Arquivo:** `quarto_passo.py`

**Descrição:** Extrai o conteúdo do arquivo `Simples.zip` para a pasta `temp`.

**Fluxo:**

```mermaid
flowchart LR
    Start([Início]) --> Check{Arquivo ZIP<br/>existe?}
    Check -->|Não| Error[Erro: Arquivo<br/>não encontrado]
    Check -->|Sim| Create[Criar Pasta<br/>temp/]
    Create --> Extract[Extrair ZIP]
    Extract --> Validate{Extração<br/>OK?}
    Validate -->|Não| Error
    Validate -->|Sim| List[Listar Arquivos<br/>Extraídos]
    List --> End([Fim])
    Error --> End
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Check fill:#FFD700
    style Error fill:#FF6B6B
    style Extract fill:#51CF66
```

**Entradas:**
- Arquivo: `Simples-{periodo}.zip`

**Saídas:**
- Diretório: `temp/`
- Arquivos CSV extraídos do ZIP

**Características:**
- Cria diretório se não existir
- Lista todos os arquivos extraídos
- Validação de integridade do ZIP

---

### Passo 5: Cruzamento de Dados

**Arquivo:** `quinto_passo.py`

**Descrição:** Faz cruzamento entre o CSV extraído e os arquivos Parquet exportados, identificando CNPJs que não estão nos Parquets.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> ReadCSV[Ler CSV<br/>da pasta temp]
    ReadCSV --> ExtractCSV[Extrair CNPJs<br/>do CSV]
    ReadCSV --> ReadParquet[Ler Parquets<br/>exportados/]
    ReadParquet --> ExtractParquet[Extrair CNPJs<br/>dos Parquets]
    ExtractCSV --> Compare[Comparar CNPJs<br/>CSV vs Parquets]
    ExtractParquet --> Compare
    Compare --> Filter[Filtrar Não<br/>Correspondentes]
    Filter --> Save[Salvar<br/>nao_correspondentes.parquet]
    Save --> Clean[Limpar Pasta<br/>temp/]
    Clean --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Compare fill:#FFD700
    style Filter fill:#DDA0DD
    style Save fill:#51CF66
```

**Entradas:**
- CSV da pasta `temp/`
- Parquets da pasta `exportados/`

**Saídas:**
- Arquivo: `nao_correspondentes.parquet`
- Pasta `temp/` é limpa após processamento

**Características:**
- Processamento em lotes para otimizar memória
- Preserva zeros à esquerda nos CNPJs
- Comparação eficiente usando sets
- Limpeza automática da pasta temp

---

### Passo 6: Separação por Ano

**Arquivo:** `sexto_passo.py`

**Descrição:** Separa o arquivo `nao_correspondentes.parquet` em arquivos por ano baseado na coluna de data (índice 3).

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Read[Ler<br/>nao_correspondentes.parquet]
    Read --> Process[Processar em<br/>Row Groups]
    Process --> Extract[Extrair Ano<br/>da Coluna Data]
    Extract --> Group[Agrupar por Ano]
    Group --> More{Mais<br/>Row Groups?}
    More -->|Sim| Process
    More -->|Não| Save[Salvar Arquivos<br/>dados_YYYY.parquet]
    Save --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Extract fill:#FFD700
    style Group fill:#DDA0DD
    style Save fill:#51CF66
```

**Entradas:**
- Arquivo: `nao_correspondentes.parquet`

**Saídas:**
- Arquivos: `dados_2007.parquet`, `dados_2008.parquet`, ...

**Características:**
- Processamento em row groups para otimizar memória
- Extração de ano do formato YYYYMMDD
- Agrupamento eficiente por ano

---

### Passo 7: Processamento e Unificação dos Dados

**Arquivo:** `setimo_passo.py`

**Descrição:** Processa todos os arquivos `dados_*.parquet`, formata os dados e unifica em uma única tabela.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Find[Encontrar Arquivos<br/>dados_*.parquet]
    Find --> Loop[Para cada Arquivo]
    Loop --> Read[Ler Parquet]
    Read --> Format[Formatar Dados:<br/>- Calcular CNPJ completo<br/>- Format datas DD/MM/YYYY<br/>- Converter motivo]
    Format --> Append[Adicionar à<br/>Lista de Tabelas]
    Append --> More{Mais<br/>arquivos?}
    More -->|Sim| Loop
    More -->|Não| Concat[Concatenar<br/>Todas Tabelas]
    Concat --> Save[Salvar<br/>tabela_unificada.parquet]
    Save --> Clean[Limpar Arquivos<br/>dados_*.parquet]
    Clean --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Format fill:#FFD700
    style Concat fill:#DDA0DD
    style Save fill:#51CF66
```

**Entradas:**
- Arquivos: `dados_*.parquet`

**Saídas:**
- Arquivo: `tabela_unificada.parquet`
- Colunas: `cnpj`, `entrada`, `saida`, `motivo`, `cnpj_raiz`

**Transformações:**
- Calcula dígitos verificadores do CNPJ
- Formata datas de YYYYMMDD para DD/MM/YYYY
- Converte motivo: N → "Excluido do simples nacional", S → "Optante pelo simples nacional"

**Características:**
- Processamento sequencial de arquivos
- Limpeza automática dos arquivos intermediários

---

### Passo 8: Processamento de Duplicados

**Arquivo:** `oitavo_passo.py`

**Descrição:** Remove duplicados baseado na coluna `cnpj_raiz`, mantendo apenas a primeira ocorrência.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Find[Encontrar<br/>tabela_unificada.parquet]
    Find --> Loop[Para cada Arquivo]
    Loop --> Read[Ler Parquet]
    Read --> Identify[Identificar Duplicados<br/>por cnpj_raiz]
    Identify --> Split[Separar:<br/>- Sem duplicados<br/>- Duplicados<br/>- Não duplicados]
    Split --> SaveTemp[Salvar Temporários<br/>em temp_processamento/]
    SaveTemp --> More{Mais<br/>arquivos?}
    More -->|Sim| Loop
    More -->|Não| Combine[Combinar Arquivos<br/>sem_duplicados]
    Combine --> FinalDup[Identificar Duplicados<br/>Entre Arquivos]
    FinalDup --> SaveFinal[Salvar<br/>todos_dados_sem_duplicacoes.parquet]
    SaveFinal --> Clean[Limpar Temp e<br/>tabela_unificada.parquet]
    Clean --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Identify fill:#FFD700
    style Split fill:#DDA0DD
    style SaveFinal fill:#51CF66
```

**Entradas:**
- Arquivo: `tabela_unificada.parquet`

**Saídas:**
- Arquivo: `todos_dados_sem_duplicacoes.parquet`

**Características:**
- Processamento em dois níveis: duplicados locais e entre arquivos
- Uso de pasta temporária para processamento
- Otimização de memória com garbage collection
- Mantém apenas primeira ocorrência de cada `cnpj_raiz`

---

### Passo 9: Divisão por Ano (Campo Saida)

**Arquivo:** `nono_passo.py`

**Descrição:** Divide o arquivo `todos_dados_sem_duplicacoes.parquet` por ano baseado no campo `saida`.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Read[Ler<br/>todos_dados_sem_duplicacoes.parquet]
    Read --> Process[Processar em<br/>Row Groups]
    Process --> Parse[Parsear Data<br/>DD/MM/YYYY]
    Parse --> Extract[Extrair Ano<br/>do Campo saida]
    Extract --> Group[Agrupar por Ano]
    Group --> More{Mais<br/>Row Groups?}
    More -->|Sim| Process
    More -->|Não| Consolidate[Consolidar Dados<br/>por Ano]
    Consolidate --> Save[Salvar Arquivos<br/>apenas_nao_duplicados_YYYY.parquet]
    Save --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Parse fill:#FFD700
    style Extract fill:#DDA0DD
    style Save fill:#51CF66
```

**Entradas:**
- Arquivo: `todos_dados_sem_duplicacoes.parquet`

**Saídas:**
- Arquivos: `apenas_nao_duplicados_2007.parquet`, `apenas_nao_duplicados_2008.parquet`, ...

**Características:**
- Processamento em row groups para otimizar memória
- Parse de datas no formato brasileiro (DD/MM/YYYY)
- Consolidação eficiente por ano
- Estatísticas de processamento

---

### Passo 10: Filtragem de Não Correspondentes

**Arquivo:** `decimo_passo.py`

**Descrição:** Filtra o arquivo `nao_correspondentes.parquet` aplicando condições específicas.

**Fluxo:**

```mermaid
flowchart LR
    Start([Início]) --> Read[Ler<br/>nao_correspondentes.parquet]
    Read --> Filter[Filtrar:<br/>f1 == 'N' AND<br/>f2 == f3]
    Filter --> Save[Salvar<br/>nao_correspondentes_filtrado.parquet]
    Save --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Filter fill:#FFD700
    style Save fill:#51CF66
```

**Entradas:**
- Arquivo: `nao_correspondentes.parquet`

**Saídas:**
- Arquivo: `nao_correspondentes_filtrado.parquet`

**Condições de Filtro:**
- `f1 == 'N'` (motivo = Não)
- `f2 == f3` (datas de entrada e saída iguais)

**Características:**
- Filtragem eficiente usando pandas
- Mantém todas as colunas originais

---

### Passo 11: Encontrar Correspondentes

**Arquivo:** `decimo_primeiro_passo.py`

**Descrição:** Encontra correspondentes entre o arquivo filtrado e os arquivos exportados da tabela `base_simples`.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> ReadFilter[Ler<br/>nao_correspondentes_filtrado.parquet]
    ReadFilter --> ExtractF0[Extrair Coluna f0<br/>CNPJs do Filtrado]
    ReadFilter --> ReadExport[Ler Parquets<br/>exportados_base_simples/]
    ReadExport --> ExtractCNPJ[Extrair cnpj_raiz<br/>dos Exportados]
    ExtractF0 --> Merge[Fazer Merge<br/>Inner Join]
    ExtractCNPJ --> Merge
    Merge --> Filter[Filtrar Registros<br/>Correspondentes]
    Filter --> ReadFull[Ler Arquivo Completo<br/>Filtrado]
    ReadFull --> Extract[Extrair Registros<br/>onde f0 está em Correspondentes]
    Extract --> Save[Salvar<br/>correspondentes_encontrados.parquet]
    Save --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Merge fill:#FFD700
    style Filter fill:#DDA0DD
    style Save fill:#51CF66
```

**Entradas:**
- Arquivo: `nao_correspondentes_filtrado.parquet`
- Parquets: `exportados_base_simples/*.parquet`

**Saídas:**
- Arquivo: `correspondentes_encontrados.parquet`

**Características:**
- Merge eficiente usando pandas
- Mantém todas as colunas dos registros correspondentes
- Remove duplicatas dos CNPJs exportados

---

### Passo 12: Atualizar dt_consulta na Tabela base_simples

**Arquivo:** `decimo_segundo_passo.py`

**Descrição:** Atualiza o campo `dt_consulta` na tabela `base_simples` com base nos registros do arquivo de correspondentes encontrados.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Read[Ler<br/>correspondentes_encontrados.parquet]
    Read --> Connect[Conectar ao<br/>PostgreSQL]
    Connect --> Loop[Para cada Registro]
    Loop --> Extract[Extrair cnpj_raiz<br/>da coluna f0]
    Extract --> Search[Buscar na Tabela<br/>base_simples]
    Search --> Found{Registro<br/>encontrado?}
    Found -->|Sim| Update[Atualizar<br/>dt_consulta]
    Found -->|Não| Log[Registrar<br/>Não Encontrado]
    Update --> More{Mais<br/>registros?}
    Log --> More
    More -->|Sim| Loop
    More -->|Não| Commit[Commit<br/>Transação]
    Commit --> End([Fim])
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Search fill:#FFD700
    style Update fill:#51CF66
    style Log fill:#FFB6C1
```

**Entradas:**
- Arquivo: `correspondentes_encontrados.parquet`
- Banco de dados: PostgreSQL (`base_simples`)

**Saídas:**
- Atualização na tabela `base_simples`
- Campo `dt_consulta` atualizado (padrão: data atual)

**Características:**
- Processamento registro a registro
- Log de progresso a cada 100 registros
- Transação única com commit ao final
- Rollback em caso de erro

---

### Passo 13: Inserir Arquivos Parquet na Tabela base_simples_periodos

**Arquivo:** `decimo_terceiro_passo.py`

**Descrição:** Lê todos os arquivos `apenas_nao_duplicados_*.parquet` e insere os registros na tabela `base_simples_periodos` do banco de dados PostgreSQL.

**Fluxo:**

```mermaid
flowchart TD
    Start([Início]) --> Find[Encontrar Arquivos<br/>apenas_nao_duplicados_*.parquet]
    Find --> Check{Arquivos<br/>encontrados?}
    Check -->|Não| Skip[Pular Passo<br/>Nenhum arquivo]
    Check -->|Sim| Connect[Conectar ao<br/>PostgreSQL]
    Connect --> Create[Verificar/Criar<br/>Tabela]
    Create --> Loop[Para cada Arquivo]
    Loop --> Read[Ler Parquet<br/>por Row Groups]
    Read --> Process[Processar Registros:<br/>- Validar cnpj_raiz<br/>- Converter datas<br/>- Verificar duplicatas]
    Process --> Batch{Alcançou<br/>batch_size?}
    Batch -->|Sim| Insert[Bulk Insert<br/>no Banco]
    Batch -->|Não| MoreReg{Mais<br/>registros?}
    Insert --> MoreReg
    MoreReg -->|Sim| Process
    MoreReg -->|Não| Commit[Commit<br/>Transação]
    Commit --> MoreFiles{Mais<br/>arquivos?}
    MoreFiles -->|Sim| Loop
    MoreFiles -->|Não| Stats[Exibir<br/>Estatísticas]
    Stats --> End([Fim])
    Skip --> End
    
    style Start fill:#90EE90
    style End fill:#90EE90
    style Check fill:#FFD700
    style Skip fill:#FFB6C1
    style Insert fill:#51CF66
    style Stats fill:#DDA0DD
```

**Entradas:**
- Arquivos: `apenas_nao_duplicados_*.parquet` (gerados no Passo 9)
- Banco de dados: PostgreSQL (`base_simples_periodos`)

**Saídas:**
- Inserção na tabela `base_simples_periodos`
- Campos inseridos: `cnpj_raiz`, `entrada`, `saida`, `motivo`

**Transformações:**
- Normaliza `cnpj_raiz` para 8 dígitos (preenche com zeros à esquerda se necessário)
- Converte datas de DD/MM/YYYY para formato Date do PostgreSQL
- Limita `motivo` a 100 caracteres
- Verifica duplicatas antes de inserir (baseado em `cnpj_raiz`, `entrada`, `saida`)

**Características:**
- Processamento em lotes (batch_size configurável, padrão: 1000)
- Processamento por row groups para otimizar memória
- Verificação de duplicatas antes de inserir
- Commit após cada arquivo processado
- Estatísticas detalhadas de inserção
- Tratamento robusto de erros com rollback
- Se não houver arquivos, retorna sucesso sem interromper o fluxo

**Modelo da Tabela:**
```sql
CREATE TABLE base_simples_periodos (
    id SERIAL PRIMARY KEY,
    cnpj_raiz VARCHAR(8) NOT NULL,
    entrada DATE,
    saida DATE,
    motivo VARCHAR(100)
);
CREATE INDEX idx_cnpj_raiz ON base_simples_periodos(cnpj_raiz);
```

---

## Estrutura de Diretórios

```
pj_simples/
├── main.py                          # Script principal
├── primeiro_passo.py                # Exportação base_simples_periodos
├── segundo_passo.py                 # Exportação base_simples
├── terceiro_passo.py                # Download Simples.zip
├── quarto_passo.py                  # Extração ZIP
├── quinto_passo.py                  # Cruzamento de dados
├── sexto_passo.py                   # Separação por ano
├── setimo_passo.py                  # Processamento e unificação
├── oitavo_passo.py                  # Remoção de duplicados
├── nono_passo.py                     # Divisão por ano (saida)
├── decimo_passo.py                   # Filtragem não correspondentes
├── decimo_primeiro_passo.py         # Encontrar correspondentes
├── decimo_segundo_passo.py          # Atualizar dt_consulta
├── decimo_terceiro_passo.py          # Inserir na base_simples_periodos
├── db.py                             # Módulo CRUD e configuração de banco
├── exportados/                      # Parquets do passo 1
│   └── cnpj_raiz_lote_*.parquet
├── exportados_base_simples/          # Parquets do passo 2
│   └── base_simples_cnpj_raiz_lote_*.parquet
├── temp/                            # Arquivos temporários (limpa após passo 5)
├── temp_processamento/              # Arquivos temporários (limpa após passo 8)
├── Simples-YYYY-MM.zip             # Arquivo baixado da Receita Federal
├── nao_correspondentes.parquet      # Resultado do passo 5
├── dados_YYYY.parquet               # Resultado do passo 6 (limpo após passo 7)
├── tabela_unificada.parquet        # Resultado do passo 7 (limpo após passo 8)
├── todos_dados_sem_duplicacoes.parquet  # Resultado do passo 8
├── apenas_nao_duplicados_YYYY.parquet   # Resultado do passo 9 (usado no passo 13)
├── nao_correspondentes_filtrado.parquet # Resultado do passo 10
├── correspondentes_encontrados.parquet  # Resultado do passo 11
└── DOCUMENTACAO.md                  # Esta documentação
```

## Uso

### Executar Todos os Passos

```bash
python main.py
```

### Executar com Período Específico

```bash
python main.py -p 2025-01
```

### Executar Passo Individual

Cada passo pode ser executado individualmente importando a função correspondente:

```python
from primeiro_passo import exportar_cnpj_raiz_para_parquet
exportar_cnpj_raiz_para_parquet()
```

## Dependências

- `psycopg2` - Conexão PostgreSQL
- `pyarrow` - Processamento Parquet
- `pandas` - Manipulação de dados
- `loguru` - Logging
- `tqdm` - Barras de progresso
- `requests` - Download de arquivos
- `sqlalchemy` - ORM para banco de dados
- `python-dotenv` - Variáveis de ambiente

## Notas Importantes

1. **Preservação de Zeros à Esquerda**: Todos os passos preservam zeros à esquerda nos CNPJs tratando-os como strings.

2. **Processamento em Lotes**: Muitos passos processam dados em lotes para otimizar o uso de memória.

3. **Limpeza Automática**: Arquivos temporários são limpos automaticamente após o uso.

4. **Validação de Arquivos**: O sistema verifica se arquivos já existem antes de processar para evitar sobrescrita.

5. **Tratamento de Erros**: Cada passo retorna `True`/`False` indicando sucesso/falha, permitindo interrupção do fluxo em caso de erro.

6. **Passo 13 Flexível**: O passo 13 verifica se existem arquivos `apenas_nao_duplicados_*.parquet` antes de processar. Se não existirem, retorna sucesso sem interromper o fluxo.

7. **Estrutura do CSV**: O arquivo CSV dentro do ZIP não possui cabeçalho e usa delimitador ponto e vírgula (`;`). As colunas são nomeadas automaticamente como `f0`, `f1`, `f2`, `f3`.

8. **Preservação de Dados**: Todos os passos preservam zeros à esquerda nos CNPJs tratando-os como strings desde a leitura inicial.
