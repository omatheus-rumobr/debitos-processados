from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
import pyarrow as pa
from sqlalchemy import Column, Integer, String, Date
from db import DatabaseManager, DatabaseConfig, Base, CRUDBase
from loguru import logger
import time
import gc
from datetime import datetime, date
from typing import List, Dict, Any


# Modelo SQLAlchemy para a tabela base_simples_periodos
class BaseSimplesPeriodos(Base):
    """Modelo para a tabela base_simples_periodos"""
    __tablename__ = 'base_simples_periodos'
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    cnpj_raiz = Column(String(8), index=True, nullable=False)
    entrada = Column(Date, nullable=True)
    saida = Column(Date, nullable=True)
    motivo = Column(String(100), nullable=True)
    
    def __repr__(self):
        return f"<BaseSimplesPeriodos(id={self.id}, cnpj_raiz={self.cnpj_raiz}, entrada={self.entrada}, saida={self.saida})>"


def parse_data_brasileira(data_str):
    """
    Converte data no padrão brasileiro (DD/MM/YYYY) para objeto date.
    Retorna None se não conseguir converter.
    """
    if data_str is None or data_str == '' or pd.isna(data_str):
        return None
    
    try:
        if isinstance(data_str, date):
            return data_str
        if isinstance(data_str, datetime):
            return data_str.date()
        
        # Tentar formato brasileiro DD/MM/YYYY
        return datetime.strptime(str(data_str), '%d/%m/%Y').date()
    except (ValueError, TypeError):
        try:
            # Tentar formato curto DD/MM/YY
            return datetime.strptime(str(data_str), '%d/%m/%y').date()
        except (ValueError, TypeError):
            try:
                # Tentar formato ISO YYYY-MM-DD
                return datetime.strptime(str(data_str), '%Y-%m-%d').date()
            except (ValueError, TypeError):
                logger.debug(f"Não foi possível converter a data: {data_str}")
                return None


def processar_arquivo_parquet(arquivo: Path, crud: CRUDBase, batch_size: int = 1000) -> Dict[str, int]:
    """
    Processa um arquivo parquet e insere os registros no banco de dados.
    
    Args:
        arquivo: Caminho do arquivo parquet
        crud: Instância CRUD para BaseSimplesPeriodos
        batch_size: Tamanho do lote para inserção em bulk
    
    Returns:
        Dicionário com estatísticas do processamento
    """
    stats = {
        'total_lidos': 0,
        'total_inseridos': 0,
        'total_erros': 0,
        'total_duplicados': 0
    }
    
    try:
        logger.info(f"Processando arquivo: {arquivo.name}")
        
        # Ler arquivo usando pyarrow
        parquet_file = pq.ParquetFile(str(arquivo))
        num_row_groups = parquet_file.metadata.num_row_groups
        logger.debug(f"  Total de row groups: {num_row_groups}")
        
        # Processar por row groups para economizar memória
        registros_batch = []
        
        for rg_idx in range(num_row_groups):
            logger.trace(f"  Processando row group {rg_idx + 1}/{num_row_groups}")
            
            # Ler row group
            table_lote = parquet_file.read_row_groups([rg_idx], use_threads=True)
            df_lote = table_lote.to_pandas()
            
            stats['total_lidos'] += len(df_lote)
            
            # Processar cada linha do DataFrame
            for _, row in df_lote.iterrows():
                try:
                    # Extrair campos (ajustar nomes conforme necessário)
                    cnpj_raiz = str(row.get('cnpj_raiz', '')).strip()
                    
                    if not cnpj_raiz or cnpj_raiz == 'nan' or len(cnpj_raiz) == 0:
                        continue
                    
                    # Garantir que cnpj_raiz tem 8 dígitos
                    if len(cnpj_raiz) > 8:
                        cnpj_raiz = cnpj_raiz[:8]
                    elif len(cnpj_raiz) < 8:
                        cnpj_raiz = cnpj_raiz.zfill(8)
                    
                    # Converter datas
                    entrada = parse_data_brasileira(row.get('entrada'))
                    saida = parse_data_brasileira(row.get('saida'))
                    motivo = str(row.get('motivo', '')).strip() if pd.notna(row.get('motivo')) else None
                    
                    # Limitar tamanho do motivo
                    if motivo and len(motivo) > 100:
                        motivo = motivo[:100]
                    
                    # Verificar se já existe (evitar duplicatas)
                    # Criar filtros apenas para campos não nulos
                    filtros = {'cnpj_raiz': cnpj_raiz}
                    if entrada:
                        filtros['entrada'] = entrada
                    if saida:
                        filtros['saida'] = saida
                    
                    registro_existente = crud.get_by(**filtros)
                    if registro_existente:
                        stats['total_duplicados'] += 1
                        continue
                    
                    # Preparar registro para inserção
                    registro = {
                        'cnpj_raiz': cnpj_raiz,
                        'entrada': entrada,
                        'saida': saida,
                        'motivo': motivo
                    }
                    
                    registros_batch.append(registro)
                    
                    # Inserir em lotes quando atingir o tamanho do batch
                    if len(registros_batch) >= batch_size:
                        try:
                            crud.bulk_create(registros_batch)
                            stats['total_inseridos'] += len(registros_batch)
                            logger.debug(f"  Inseridos {len(registros_batch)} registros (total: {stats['total_inseridos']:,})")
                            registros_batch = []
                        except Exception as e:
                            logger.error(f"  Erro ao inserir lote: {e}")
                            stats['total_erros'] += len(registros_batch)
                            registros_batch = []
                            
                except Exception as e:
                    logger.debug(f"  Erro ao processar linha: {e}")
                    stats['total_erros'] += 1
                    continue
            
            del table_lote
            del df_lote
            gc.collect()
        
        # Inserir registros restantes
        if registros_batch:
            try:
                crud.bulk_create(registros_batch)
                stats['total_inseridos'] += len(registros_batch)
                logger.debug(f"  Inseridos {len(registros_batch)} registros finais")
            except Exception as e:
                logger.error(f"  Erro ao inserir lote final: {e}")
                stats['total_erros'] += len(registros_batch)
        
        del parquet_file
        gc.collect()
        
        logger.success(f"  Arquivo {arquivo.name} processado: {stats['total_inseridos']:,} inseridos, {stats['total_duplicados']:,} duplicados, {stats['total_erros']:,} erros")
        
    except Exception as e:
        logger.exception(f"Erro ao processar arquivo {arquivo.name}: {e}")
        stats['total_erros'] += stats['total_lidos'] - stats['total_inseridos']
    
    return stats


def inserir_parquets_no_banco(diretorio_base: str = ".", batch_size: int = 1000):
    """
    Lê todos os arquivos apenas_nao_duplicados_*.parquet e insere na tabela base_simples_periodos.
    
    Args:
        diretorio_base: Diretório base onde estão os arquivos parquet
        batch_size: Tamanho do lote para inserção em bulk (padrão: 1000)
    """
    inicio_total = time.time()
    
    diretorio_base = Path(diretorio_base)
    
    logger.info("=" * 80)
    logger.info("INSERÇÃO DE ARQUIVOS PARQUET NO BANCO DE DADOS")
    logger.info("=" * 80)
    logger.info(f"Diretório base: {diretorio_base.absolute()}")
    
    # Encontrar arquivos apenas_nao_duplicados_*.parquet
    logger.info("\n[ETAPA 1] Procurando arquivos apenas_nao_duplicados_*.parquet...")
    arquivos_parquet = sorted(diretorio_base.glob("apenas_nao_duplicados_*.parquet"))
    
    if not arquivos_parquet:
        logger.error("Nenhum arquivo apenas_nao_duplicados_*.parquet encontrado.")
        return
    
    logger.info(f"Encontrados {len(arquivos_parquet)} arquivo(s) parquet")
    
    # Configurar conexão com banco de dados
    logger.info("\n[ETAPA 2] Conectando ao banco de dados...")
    db_config = DatabaseConfig()
    db_manager = DatabaseManager(config=db_config, echo=False)
    
    # Criar tabela se não existir
    try:
        db_manager.create_tables()
        logger.debug("Tabelas verificadas/criadas")
    except Exception as e:
        logger.warning(f"Aviso ao criar tabelas: {e}")
    
    # Obter sessão e CRUD
    session = db_manager.get_session()
    crud = db_manager.get_crud(BaseSimplesPeriodos, session)
    
    # Estatísticas totais
    stats_total = {
        'total_lidos': 0,
        'total_inseridos': 0,
        'total_erros': 0,
        'total_duplicados': 0
    }
    
    try:
        # Processar cada arquivo
        logger.info("\n[ETAPA 3] Processando arquivos e inserindo no banco...")
        
        for idx, arquivo in enumerate(arquivos_parquet, 1):
            logger.info(f"\n[ARQUIVO {idx}/{len(arquivos_parquet)}] {arquivo.name}")
            
            stats_arquivo = processar_arquivo_parquet(arquivo, crud, batch_size)
            
            # Atualizar estatísticas totais
            for key in stats_total:
                stats_total[key] += stats_arquivo[key]
            
            # Commit após cada arquivo
            try:
                session.commit()
                logger.debug(f"  Commit realizado para {arquivo.name}")
            except Exception as e:
                logger.error(f"  Erro no commit: {e}")
                session.rollback()
        
        # Commit final
        session.commit()
        logger.success("Commit final realizado com sucesso!")
        
    except Exception as e:
        logger.exception(f"Erro durante o processamento: {e}")
        session.rollback()
    finally:
        session.close()
    
    tempo_total = time.time() - inicio_total
    
    # Resumo final
    logger.info("\n" + "=" * 80)
    logger.info("RESUMO DA INSERÇÃO")
    logger.info("=" * 80)
    logger.info(f"Total de arquivos processados: {len(arquivos_parquet)}")
    logger.info(f"Total de registros lidos: {stats_total['total_lidos']:,}")
    logger.info(f"Total de registros inseridos: {stats_total['total_inseridos']:,}")
    logger.info(f"Total de duplicados (ignorados): {stats_total['total_duplicados']:,}")
    logger.info(f"Total de erros: {stats_total['total_erros']:,}")
    logger.info(f"Tempo total: {tempo_total:.2f}s ({tempo_total/60:.2f} minutos)")
    if stats_total['total_inseridos'] > 0:
        taxa = stats_total['total_inseridos'] / tempo_total
        logger.info(f"Taxa de inserção: {taxa:,.0f} registros/segundo")
    logger.info("=" * 80)


def main():
    """Função principal"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Lê arquivos apenas_nao_duplicados_*.parquet e insere na tabela base_simples_periodos',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
            Exemplos:
            python testes.py
            python testes.py --diretorio ./dados
            python testes.py --batch-size 5000
        """
    )
    
    parser.add_argument(
        '--diretorio',
        type=str,
        default='.',
        help='Diretório base onde estão os arquivos parquet (padrão: diretório atual)'
    )
    
    parser.add_argument(
        '--batch-size',
        type=int,
        default=1000,
        help='Tamanho do lote para inserção em bulk (padrão: 1000)'
    )
    
    args = parser.parse_args()
    
    logger.debug(f"Argumentos recebidos: diretorio={args.diretorio}, batch_size={args.batch_size}")
    
    try:
        inserir_parquets_no_banco(args.diretorio, args.batch_size)
        logger.success("\nProcessamento concluído com sucesso!")
    except Exception as e:
        logger.exception(f"Erro durante o processamento: {e}")
        raise


if __name__ == "__main__":
    main()
