"""
Script principal que executa todos os passos do processamento em sequência.
"""

from pathlib import Path
from loguru import logger
from datetime import datetime

# Importar funções dos módulos
from primeiro_passo import exportar_cnpj_raiz_para_parquet as exportar_cnpj_raiz_periodos
from segundo_passo import exportar_cnpj_raiz_para_parquet as exportar_cnpj_raiz_simples
from terceiro_passo import baixar_arquivo, construir_url
from quarto_passo import extrair_simples_zip
from quinto_passo import fazer_cruzamento, limpar_pasta_temp
from sexto_passo import separar_por_ano
from setimo_passo import processar_arquivos_e_gerar_tabela, salvar_tabela_parquet
from nono_passo import dividir_parquet_por_ano
from decimo_passo import filtrar_nao_correspondentes
from decimo_primeiro_passo import encontrar_correspondentes
from decimo_segundo_passo import atualizar_dt_consulta
from decimo_terceiro_passo import inserir_parquets_no_banco


# Configurar logger
logger.remove()
logger.add(
    sink=lambda msg: print(msg, end=""),
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
    colorize=True
)


def executar_primeiro_passo(script_dir):
    """
    Executa o primeiro passo: exportar cnpj_raiz da tabela base_simples_periodos.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 1: EXPORTAÇÃO CNPJ_RAIZ - BASE_SIMPLES_PERIODOS")
    logger.info("=" * 80)
    
    try:
        exportar_cnpj_raiz_periodos()
        logger.success("✓ PASSO 1 CONCLUÍDO COM SUCESSO!")
        return True
    except Exception as e:
        logger.exception(f"Erro no passo 1: {e}")
        return False


def executar_segundo_passo(script_dir):
    """
    Executa o segundo passo: exportar cnpj_raiz da tabela base_simples.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 2: EXPORTAÇÃO CNPJ_RAIZ - BASE_SIMPLES")
    logger.info("=" * 80)
    
    try:
        exportar_cnpj_raiz_simples()
        logger.success("✓ PASSO 2 CONCLUÍDO COM SUCESSO!")
        return True
    except Exception as e:
        logger.exception(f"Erro no passo 2: {e}")
        return False


def executar_terceiro_passo(script_dir, periodo=None):
    """
    Executa o terceiro passo: baixar arquivo Simples.zip da Receita Federal.
    
    Args:
        script_dir: Diretório do script (Path)
        periodo: Período no formato YYYY-MM (opcional, padrão: período atual)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 3: DOWNLOAD DO ARQUIVO SIMPLES.ZIP")
    logger.info("=" * 80)
    
    try:
        if periodo is None:
            periodo = datetime.now().strftime("%Y-%m")
        
        nome_arquivo_base = f"Simples-{periodo}.zip"
        nome_arquivo = script_dir / nome_arquivo_base
        
        if nome_arquivo.exists() and nome_arquivo.is_file():
            tamanho_arquivo = nome_arquivo.stat().st_size
            logger.warning("=" * 60)
            logger.warning(f"Arquivo '{nome_arquivo.name}' já existe!")
            logger.warning(f"Caminho: {nome_arquivo.absolute()}")
            logger.warning(f"Tamanho: {tamanho_arquivo / (1024*1024):.2f} MB")
            logger.warning("Download não será executado para evitar sobrescrever arquivo existente.")
            logger.warning("=" * 60)
            logger.success(f"✓ PASSO 3 CONCLUÍDO (arquivo já existe)!")
            return True
        
        logger.info(f"Arquivo não encontrado. Iniciando download para o período: {periodo}")
        link = construir_url(periodo)
        arquivo_baixado = baixar_arquivo(link, nome_arquivo=str(nome_arquivo))
        
        if arquivo_baixado:
            logger.success(f"✓ PASSO 3 CONCLUÍDO COM SUCESSO!")
            logger.info(f"Arquivo salvo em: {Path(arquivo_baixado).absolute()}")
            return True
        else:
            logger.error("✗ PASSO 3 FALHOU! Download não foi concluído.")
            return False
            
    except Exception as e:
        logger.exception(f"Erro no passo 3: {e}")
        return False


def executar_quarto_passo(script_dir, periodo=None):
    """
    Executa o quarto passo: extrair arquivo ZIP.
    
    Args:
        script_dir: Diretório do script (Path)
        periodo: Período no formato YYYY-MM (opcional, padrão: período atual)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 4: EXTRAÇÃO DO ARQUIVO ZIP")
    logger.info("=" * 80)
    
    try:
        if periodo is None:
            periodo = datetime.now().strftime("%Y-%m")
        
        arquivo_zip = script_dir / f"Simples-{periodo}.zip"
        pasta_destino = script_dir / "temp"
        
        if not arquivo_zip.exists():
            logger.error(f"Arquivo '{arquivo_zip}' não encontrado!")
            return False
        
        sucesso = extrair_simples_zip(str(arquivo_zip), str(pasta_destino))
        
        if sucesso:
            logger.success("✓ PASSO 4 CONCLUÍDO COM SUCESSO!")
        else:
            logger.error("✗ PASSO 4 FALHOU!")
        
        return sucesso
        
    except Exception as e:
        logger.exception(f"Erro no passo 4: {e}")
        return False


def executar_quinto_passo(script_dir):
    """
    Executa o quinto passo: cruzamento de dados.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 5: CRUZAMENTO DE DADOS")
    logger.info("=" * 80)
    
    try:
        pasta_exportados = script_dir / "exportados"
        lista_parquets = sorted(pasta_exportados.glob("*.parquet"))
        
        if not lista_parquets:
            logger.error(f"Nenhum arquivo Parquet encontrado na pasta '{pasta_exportados}'")
            return False
        
        logger.info(f"Encontrados {len(lista_parquets)} arquivo(s) Parquet na pasta 'exportados'")
        
        pasta_temp = script_dir / "temp"
        arquivos_temp = list(pasta_temp.glob("*"))
        arquivos_csv_temp = [f for f in arquivos_temp if f.is_file() and not f.name.startswith('.')]
        
        if not arquivos_csv_temp:
            logger.error(f"Nenhum arquivo encontrado na pasta '{pasta_temp}'")
            return False
        
        if len(arquivos_csv_temp) > 1:
            logger.warning(f"Múltiplos arquivos encontrados na pasta temp. Usando o primeiro: {arquivos_csv_temp[0].name}")
        
        file_csv = arquivos_csv_temp[0]
        logger.info(f"Usando arquivo CSV: {file_csv.name}")
        
        parquet_nao_correspondentes = script_dir / "nao_correspondentes.parquet"
        
        fazer_cruzamento(
            str(file_csv),
            [str(p) for p in lista_parquets],
            str(parquet_nao_correspondentes)
        )
        
        logger.info("=" * 60)
        logger.info("LIMPANDO PASTA TEMP...")
        logger.info("=" * 60)
        limpar_pasta_temp(pasta_temp)
        
        logger.success("✓ PASSO 5 CONCLUÍDO COM SUCESSO!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro no passo 5: {e}")
        return False


def executar_sexto_passo(script_dir):
    """
    Executa o sexto passo: separação por ano.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 6: SEPARAÇÃO POR ANO")
    logger.info("=" * 80)
    
    try:
        arquivo_parquet = script_dir / "nao_correspondentes.parquet"
        
        if not arquivo_parquet.exists():
            logger.error(f"Arquivo '{arquivo_parquet}' não encontrado!")
            return False
        
        diretorio_saida = script_dir
        
        separar_por_ano(str(arquivo_parquet), str(diretorio_saida))
        
        logger.success("✓ PASSO 6 CONCLUÍDO COM SUCESSO!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro no passo 6: {e}")
        return False


def executar_setimo_passo(script_dir):
    """
    Executa o sétimo passo: processamento e unificação dos dados.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 7: PROCESSAMENTO E UNIFICAÇÃO DOS DADOS")
    logger.info("=" * 80)
    
    try:
        diretorio_parquet = script_dir
        tabela_unificada = processar_arquivos_e_gerar_tabela(diretorio_parquet)
        
        if tabela_unificada is not None:
            caminho_parquet = script_dir / "tabela_unificada.parquet"
            salvar_tabela_parquet(tabela_unificada, caminho_parquet)
            
            logger.info("\n" + "=" * 80)
            logger.info(f"Total de linhas na tabela completa: {len(tabela_unificada):,}")
            logger.info(f"Arquivo Parquet salvo em: {caminho_parquet}")
            logger.info("=" * 80)
            
            # Limpar arquivos dados_*.parquet
            logger.info("\n" + "=" * 60)
            logger.info("LIMPANDO ARQUIVOS dados_*.parquet...")
            logger.info("=" * 60)
            
            arquivos_dados = list(script_dir.glob("dados_*.parquet"))
            if arquivos_dados:
                arquivos_removidos = 0
                for arquivo in arquivos_dados:
                    try:
                        tamanho_mb = arquivo.stat().st_size / (1024 * 1024)
                        arquivo.unlink()
                        logger.info(f"  ✓ Removido: {arquivo.name} ({tamanho_mb:.2f} MB)")
                        arquivos_removidos += 1
                    except Exception as e:
                        logger.warning(f"  ✗ Erro ao remover {arquivo.name}: {e}")
                
                logger.info(f"Total de arquivos removidos: {arquivos_removidos}")
            else:
                logger.info("Nenhum arquivo dados_*.parquet encontrado para remover.")
            
            logger.success("✓ PASSO 7 CONCLUÍDO COM SUCESSO!")
            return True
        else:
            logger.error("Nenhuma tabela foi gerada!")
            return False
            
    except Exception as e:
        logger.exception(f"Erro no passo 7: {e}")
        return False


def executar_oitavo_passo(script_dir):
    """
    Executa o oitavo passo: processamento de duplicados.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 8: PROCESSAMENTO DE DUPLICADOS")
    logger.info("=" * 80)
    
    try:
        # O oitavo_passo usa Path(__file__).parent, então precisamos mudar temporariamente
        # ou adaptar a função. Vamos importar as funções necessárias diretamente
        from oitavo_passo import encontrar_arquivos_parquet, processar_arquivo_individual
        from oitavo_passo import combinar_arquivos_sem_duplicados
        import shutil
        
        pasta_temp = script_dir / "temp_processamento"
        
        # Limpar pasta temp anterior se existir
        if pasta_temp.exists():
            logger.info("Limpando pasta temporária anterior...")
            shutil.rmtree(pasta_temp)
        pasta_temp.mkdir(parents=True, exist_ok=True)
        
        # Encontrar arquivos
        arquivos = encontrar_arquivos_parquet(script_dir)
        
        if not arquivos:
            logger.error("Nenhum arquivo tabela_unificada.parquet encontrado!")
            return False
        
        logger.info(f"Encontrados {len(arquivos)} arquivo(s) para processar")
        
        # Processar arquivos individualmente
        stats_totais = {'total': 0, 'duplicados': 0, 'nao_duplicados': 0}
        
        for i, arquivo in enumerate(arquivos, 1):
            logger.info(f"[{i}/{len(arquivos)}] Processando arquivo...")
            try:
                stats = processar_arquivo_individual(arquivo, pasta_temp)
                stats_totais['total'] += stats['total']
                stats_totais['duplicados'] += stats['duplicados']
                stats_totais['nao_duplicados'] += stats['nao_duplicados']
            except Exception as e:
                logger.error(f"Erro ao processar {arquivo}: {e}")
                continue
        
        # Combinar resultados e gerar apenas o arquivo todos_dados_sem_duplicacoes.parquet
        combinar_arquivos_sem_duplicados(
            pasta_temp,
            script_dir / "todos_dados_sem_duplicacoes.parquet"
        )
        
        # Limpar pasta temp
        try:
            shutil.rmtree(pasta_temp)
            logger.info("Arquivos temporários removidos com sucesso")
        except Exception as e:
            logger.warning(f"Erro ao remover arquivos temporários: {e}")
        
        # Remover arquivo tabela_unificada.parquet
        arquivo_tabela_unificada = script_dir / "tabela_unificada.parquet"
        if arquivo_tabela_unificada.exists():
            try:
                tamanho_mb = arquivo_tabela_unificada.stat().st_size / (1024 * 1024)
                arquivo_tabela_unificada.unlink()
                logger.info(f"Arquivo 'tabela_unificada.parquet' removido ({tamanho_mb:.2f} MB)")
            except Exception as e:
                logger.warning(f"Erro ao remover arquivo 'tabela_unificada.parquet': {e}")
        else:
            logger.info("Arquivo 'tabela_unificada.parquet' não encontrado para remover.")
        
        logger.success("✓ PASSO 8 CONCLUÍDO COM SUCESSO!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro no passo 8: {e}")
        return False


def executar_nono_passo(script_dir):
    """
    Executa o nono passo: divisão do arquivo parquet por ano.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 9: DIVISÃO POR ANO (CAMPO SAIDA)")
    logger.info("=" * 80)
    
    try:
        arquivo_entrada = script_dir / "todos_dados_sem_duplicacoes.parquet"
        
        if not arquivo_entrada.exists():
            logger.error(f"Arquivo '{arquivo_entrada}' não encontrado!")
            return False
        
        diretorio_saida = script_dir
        
        dividir_parquet_por_ano(str(arquivo_entrada), str(diretorio_saida))
        
        logger.success("✓ PASSO 9 CONCLUÍDO COM SUCESSO!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro no passo 9: {e}")
        return False


def executar_decimo_passo(script_dir):
    """
    Executa o décimo passo: filtrar arquivo nao_correspondentes.parquet.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 10: FILTRAGEM DE NÃO CORRESPONDENTES")
    logger.info("=" * 80)
    
    try:
        sucesso = filtrar_nao_correspondentes(script_dir)
        
        if sucesso:
            logger.success("✓ PASSO 10 CONCLUÍDO COM SUCESSO!")
        else:
            logger.error("✗ PASSO 10 FALHOU!")
        
        return sucesso
        
    except Exception as e:
        logger.exception(f"Erro no passo 10: {e}")
        return False


def executar_decimo_primeiro_passo(script_dir):
    """
    Executa o décimo primeiro passo: encontrar correspondentes entre arquivos filtrados e exportados.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 11: ENCONTRAR CORRESPONDENTES")
    logger.info("=" * 80)
    
    try:
        sucesso = encontrar_correspondentes(script_dir)
        
        if sucesso:
            logger.success("✓ PASSO 11 CONCLUÍDO COM SUCESSO!")
        else:
            logger.error("✗ PASSO 11 FALHOU!")
        
        return sucesso
        
    except Exception as e:
        logger.exception(f"Erro no passo 11: {e}")
        return False


def executar_decimo_segundo_passo(script_dir, dt_consulta=None):
    """
    Executa o décimo segundo passo: atualizar dt_consulta na tabela base_simples.
    
    Args:
        script_dir: Diretório do script (Path)
        dt_consulta: Data de consulta (date, opcional). Se None, usa a data atual.
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 12: ATUALIZAR DT_CONSULTA NA TABELA BASE_SIMPLES")
    logger.info("=" * 80)
    
    try:
        sucesso = atualizar_dt_consulta(script_dir, dt_consulta)
        
        if sucesso:
            logger.success("✓ PASSO 12 CONCLUÍDO COM SUCESSO!")
        else:
            logger.error("✗ PASSO 12 FALHOU!")
        
        return sucesso
        
    except Exception as e:
        logger.exception(f"Erro no passo 12: {e}")
        return False


def executar_decimo_terceiro_passo(script_dir, batch_size=1000):
    """
    Executa o décimo terceiro passo: inserir arquivos apenas_nao_duplicados_*.parquet na tabela base_simples_periodos.
    
    Args:
        script_dir: Diretório do script (Path)
        batch_size: Tamanho do lote para inserção em bulk (padrão: 1000)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    logger.info("=" * 80)
    logger.info("PASSO 13: INSERIR ARQUIVOS PARQUET NA TABELA BASE_SIMPLES_PERIODOS")
    logger.info("=" * 80)
    
    try:
        # Verificar se existem arquivos apenas_nao_duplicados_*.parquet
        arquivos_parquet = sorted(script_dir.glob("apenas_nao_duplicados_*.parquet"))
        
        if not arquivos_parquet:
            logger.warning("Nenhum arquivo apenas_nao_duplicados_*.parquet encontrado.")
            logger.warning("Passo 13 será pulado.")
            return True  # Retorna True para não interromper o fluxo
        
        logger.info(f"Encontrados {len(arquivos_parquet)} arquivo(s) apenas_nao_duplicados_*.parquet")
        
        inserir_parquets_no_banco(str(script_dir), batch_size)
        
        logger.success("✓ PASSO 13 CONCLUÍDO COM SUCESSO!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro no passo 13: {e}")
        return False


def limpar_arquivos_parquet(script_dir):
    """
    Remove todos os arquivos .parquet do diretório do script.
    
    Args:
        script_dir: Diretório do script (Path)
    """
    logger.info("=" * 80)
    logger.info("LIMPEZA DE ARQUIVOS PARQUET")
    logger.info("=" * 80)
    
    try:
        arquivos_parquet = list(script_dir.glob("*.parquet"))
        
        if not arquivos_parquet:
            logger.info("Nenhum arquivo .parquet encontrado para remover.")
            return
        
        logger.info(f"Encontrados {len(arquivos_parquet)} arquivo(s) .parquet para remover:")
        
        arquivos_removidos = 0
        arquivos_com_erro = 0
        
        for arquivo in arquivos_parquet:
            try:
                tamanho_mb = arquivo.stat().st_size / (1024 * 1024)
                arquivo.unlink()
                logger.info(f"  ✓ Removido: {arquivo.name} ({tamanho_mb:.2f} MB)")
                arquivos_removidos += 1
            except Exception as e:
                logger.error(f"  ✗ Erro ao remover {arquivo.name}: {e}")
                arquivos_com_erro += 1
        
        logger.info(f"\nTotal removido: {arquivos_removidos} arquivo(s)")
        if arquivos_com_erro > 0:
            logger.warning(f"Erros ao remover: {arquivos_com_erro} arquivo(s)")
        else:
            logger.success("✓ Todos os arquivos .parquet foram removidos com sucesso!")
            
    except Exception as e:
        logger.exception(f"Erro ao limpar arquivos .parquet: {e}")


def main(periodo=None):
    """
    Função principal que executa todos os passos em sequência.
    
    Args:
        periodo: Período no formato YYYY-MM (opcional, padrão: período atual)
    """
    logger.info("=" * 80)
    logger.info("INICIANDO PROCESSAMENTO COMPLETO")
    logger.info("=" * 80)
    
    script_dir = Path(__file__).parent.resolve()
    
    if periodo is None:
        periodo = datetime.now().strftime("%Y-%m")
    
    logger.info(f"Período configurado: {periodo}")

    passos = [
        ("Passo 1 - Exportação CNPJ_RAIZ (base_simples_periodos)", lambda: executar_primeiro_passo(script_dir)),
        ("Passo 2 - Exportação CNPJ_RAIZ (base_simples)", lambda: executar_segundo_passo(script_dir)),
        ("Passo 3 - Download Simples.zip", lambda: executar_terceiro_passo(script_dir, periodo)),
        ("Passo 4 - Extração ZIP", lambda: executar_quarto_passo(script_dir, periodo)),
        ("Passo 5 - Cruzamento de dados", lambda: executar_quinto_passo(script_dir)),
        ("Passo 6 - Separação por ano", lambda: executar_sexto_passo(script_dir)),
        ("Passo 7 - Processamento e unificação", lambda: executar_setimo_passo(script_dir)),
        ("Passo 8 - Processamento de duplicados", lambda: executar_oitavo_passo(script_dir)),
        ("Passo 9 - Divisão por ano (campo saida)", lambda: executar_nono_passo(script_dir)),
        ("Passo 10 - Filtragem de não correspondentes", lambda: executar_decimo_passo(script_dir)),
        ("Passo 11 - Encontrar correspondentes", lambda: executar_decimo_primeiro_passo(script_dir)),
        ("Passo 12 - Atualizar dt_consulta na tabela base_simples", lambda: executar_decimo_segundo_passo(script_dir)),
        ("Passo 13 - Inserir arquivos parquet na tabela base_simples_periodos", lambda: executar_decimo_terceiro_passo(script_dir)),
    ]
    
    resultados = {}
    
    for nome_passo, funcao_passo in passos:
        try:
            sucesso = funcao_passo()
            resultados[nome_passo] = sucesso
            
            if not sucesso:
                logger.error(f"\n{nome_passo} falhou! Interrompendo execução.")
                break
                
        except Exception as e:
            logger.exception(f"Erro crítico em {nome_passo}: {e}")
            resultados[nome_passo] = False
            break
    

    logger.info("\n" + "=" * 80)
    logger.info("RESUMO DA EXECUÇÃO")
    logger.info("=" * 80)
    
    for nome_passo, sucesso in resultados.items():
        status = "✓ SUCESSO" if sucesso else "✗ FALHOU"
        logger.info(f"{nome_passo}: {status}")
    
    todos_sucesso = all(resultados.values())
    
    if todos_sucesso:
        logger.success("\n" + "=" * 80)
        logger.success("✓ TODOS OS PASSOS FORAM EXECUTADOS COM SUCESSO!")
        logger.success("=" * 80)
    else:
        logger.error("\n" + "=" * 80)
        logger.error("✗ PROCESSAMENTO INTERROMPIDO OU FALHOU!")
        logger.error("=" * 80)
    

    # limpar_arquivos_parquet(script_dir)


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Executa todos os passos do processamento em sequência."
    )
    parser.add_argument(
        "-p", "--periodo",
        type=str,
        default=None,
        help="Período no formato YYYY-MM (ex: 2025-12). Se não especificado, usa o período atual."
    )
    
    args = parser.parse_args()
    main(periodo=args.periodo)
