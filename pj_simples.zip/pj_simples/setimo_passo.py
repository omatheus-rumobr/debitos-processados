import pyarrow.csv as csv
import pyarrow as pa
import pyarrow.parquet as pq
from loguru import logger
import time
from pathlib import Path


def ler_parquet_otimizado(caminho_parquet, converter_para_pandas=False):
    """
    Lê um arquivo Parquet de forma otimizada usando PyArrow.
    
    Esta função utiliza as melhores práticas do PyArrow para leitura eficiente:
    - Processamento paralelo com múltiplas threads
    - Leitura otimizada de arquivos Parquet
    - Preservação de tipos de dados
    
    Args:
        caminho_parquet: Caminho para o arquivo Parquet (str ou Path)
        converter_para_pandas: Se True, retorna um DataFrame pandas. Se False, retorna uma Table PyArrow
        
    Returns:
        pyarrow.Table ou pandas.DataFrame: Dados lidos do Parquet
    """
    caminho_parquet = Path(caminho_parquet)
    inicio = time.time()
    
    logger.info(f"Iniciando leitura do arquivo: {caminho_parquet}")

    tabela = pq.read_table(
        str(caminho_parquet),
        use_threads=True
    )
    
    tempo_leitura = time.time() - inicio
    
    num_linhas = len(tabela)
    num_colunas = len(tabela.column_names)
    
    logger.info(f"Leitura concluída em {tempo_leitura:.2f} segundos")
    logger.info(f"Linhas: {num_linhas:,} | Colunas: {num_colunas}")
    logger.info(f"Colunas: {tabela.column_names}")

    if converter_para_pandas:
        logger.info("Convertendo para DataFrame pandas...")
        inicio_conversao = time.time()
        df = tabela.to_pandas()
        tempo_conversao = time.time() - inicio_conversao
        logger.info(f"Conversão concluída em {tempo_conversao:.2f} segundos")
        return df
    
    return tabela


def ler_csv_em_lotes(caminho_csv):
    """
    Lê um arquivo CSV em lotes para processar arquivos muito grandes
    sem carregar tudo na memória de uma vez.
    
    Args:
        caminho_csv: Caminho para o arquivo CSV (str ou Path)
        tamanho_lote: Número de linhas por lote (padrão: 1 milhão)
        
    Yields:
        pyarrow.Table: Lote de dados do CSV
    """
    caminho_csv = Path(caminho_csv)
    parse_options = csv.ParseOptions(
        delimiter=',',
        quote_char='"',
        escape_char=None,
        double_quote=True,
        newlines_in_values=False,
        ignore_empty_lines=True
    )
    
    convert_options = csv.ConvertOptions(
        strings_can_be_null=True,
        null_values=['', 'NULL', 'null', 'None'],
        auto_dict_encode=True,
        auto_dict_max_cardinality=0.8,
        check_utf8=False,
    )
    
    read_options = csv.ReadOptions(
        use_threads=True,
        block_size=10485760,
        skip_rows=0,
        column_names=None,
    )
    
    logger.info(f"Iniciando leitura em lotes do arquivo: {caminho_csv}")

    with csv.open_csv(
        str(caminho_csv),
        read_options=read_options,
        parse_options=parse_options,
        convert_options=convert_options
    ) as reader:
        lote_numero = 0
        while True:
            try:
                lote = reader.read_next_batch()
                if lote is None or len(lote) == 0:
                    break
                
                lote_numero += 1
                logger.info(f"Lote {lote_numero}: {len(lote):,} linhas")
                yield pa.Table.from_batches([lote])
                
            except StopIteration:
                break
    
    logger.info(f"Leitura em lotes concluída. Total de {lote_numero} lotes processados.")


def calcular_digitos_cnpj(cnpj_raiz):
    """
    Calcula os dígitos verificadores do CNPJ a partir do CNPJ raiz (8 dígitos).
    Retorna o CNPJ completo com 14 dígitos (8 raiz + 4 filial padrão 0001 + 2 dígitos verificadores).
    
    Args:
        cnpj_raiz: CNPJ raiz como int ou string (8 dígitos)
        
    Returns:
        str: CNPJ completo com 14 dígitos
    """
    try:

        cnpj_raiz_str = str(int(cnpj_raiz)).zfill(8)
        

        cnpj_base = cnpj_raiz_str + "0001"
        

        multiplicadores1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        soma = sum(int(cnpj_base[i]) * multiplicadores1[i] for i in range(12))
        resto = soma % 11
        digito1 = 0 if resto < 2 else 11 - resto
        

        multiplicadores2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        cnpj_com_digito1 = cnpj_base + str(digito1)
        soma = sum(int(cnpj_com_digito1[i]) * multiplicadores2[i] for i in range(13))
        resto = soma % 11
        digito2 = 0 if resto < 2 else 11 - resto
        

        return cnpj_base + str(digito1) + str(digito2)
    except (ValueError, TypeError):
        return None


def formatar_data(data_int):
    """
    Formata data de YYYYMMDD (int) para DD/MM/YYYY (string).
    
    Args:
        data_int: Data no formato YYYYMMDD como int
        
    Returns:
        str: Data formatada como DD/MM/YYYY ou string vazia se inválida
    """
    try:
        if data_int is None or data_int == 0:
            return ""
        
        data_str = str(int(data_int)).zfill(8)
        
        if len(data_str) == 8:
            ano = data_str[0:4]
            mes = data_str[4:6]
            dia = data_str[6:8]
            return f"{dia}/{mes}/{ano}"
        else:
            return ""
    except (ValueError, TypeError):
        return ""


def converter_motivo(motivo):
    """
    Converte o valor do motivo (N/n ou S/s) para texto descritivo.
    
    Args:
        motivo: String com N, n, S ou s
        
    Returns:
        str: Texto descritivo do motivo
    """
    if motivo is None:
        return ""
    
    motivo_str = str(motivo).strip().upper()
    
    if motivo_str == "N":
        return "Excluido do simples nacional"
    elif motivo_str == "S":
        return "Optante pelo simples nacional"
    else:
        return ""


def processar_arquivos_e_gerar_tabela(diretorio="."):
    """
    Processa todos os arquivos dados_*.parquet e gera uma tabela única
    com a formatação especificada.
    
    Args:
        diretorio: Diretório onde estão os arquivos Parquet (str ou Path, padrão: diretório atual)
        
    Returns:
        pyarrow.Table: Tabela unificada com os dados formatados
    """
    diretorio = Path(diretorio)
    logger.info("=" * 60)
    logger.info("INICIANDO PROCESSAMENTO DOS ARQUIVOS PARQUET")
    logger.info("=" * 60)
    

    arquivos = sorted(diretorio.glob("dados_*.parquet"))
    
    if not arquivos:
        logger.warning(f"Nenhum arquivo encontrado com o padrão: dados_*.parquet em {diretorio}")
        return None
    
    logger.info(f"Encontrados {len(arquivos)} arquivos para processar")
    
    todas_tabelas = []
    total_linhas_processadas = 0
    
    for arquivo in arquivos:
        logger.info(f"\nProcessando: {arquivo.name}")
        

        tabela = ler_parquet_otimizado(arquivo, converter_para_pandas=False)
        
        if len(tabela) == 0:
            logger.warning(f"Arquivo {arquivo} está vazio, pulando...")
            continue
        

        df = tabela.to_pandas()
        

        
        col_cnpj_raiz = df.iloc[:, 0]
        col_motivo = df.iloc[:, 1]
        col_entrada = df.iloc[:, 2]
        col_saida = df.iloc[:, 3]
        

        cnpjs_completos = []
        entradas_formatadas = []
        saidas_formatadas = []
        motivos_convertidos = []
        cnpjs_raiz = []
        
        logger.info(f"Processando {len(df):,} linhas...")
        
        for idx in range(len(df)):

            cnpj_raiz_val = col_cnpj_raiz.iloc[idx]
            cnpj_completo = calcular_digitos_cnpj(cnpj_raiz_val)
            cnpjs_completos.append(cnpj_completo if cnpj_completo else "")
            

            entrada_val = col_entrada.iloc[idx]
            entrada_formatada = formatar_data(entrada_val)
            entradas_formatadas.append(entrada_formatada)
            

            saida_val = col_saida.iloc[idx]
            saida_formatada = formatar_data(saida_val)
            saidas_formatadas.append(saida_formatada)
            

            motivo_val = col_motivo.iloc[idx]
            motivo_convertido = converter_motivo(motivo_val)
            motivos_convertidos.append(motivo_convertido)
            

            cnpj_raiz_str = str(int(cnpj_raiz_val)).zfill(8) if cnpj_raiz_val is not None else ""
            cnpjs_raiz.append(cnpj_raiz_str)
        

        nova_tabela = pa.table({
            'cnpj': cnpjs_completos,
            'entrada': entradas_formatadas,
            'saida': saidas_formatadas,
            'motivo': motivos_convertidos,
            'cnpj_raiz': cnpjs_raiz
        })
        
        todas_tabelas.append(nova_tabela)
        total_linhas_processadas += len(nova_tabela)
        
        logger.info(f"Arquivo processado: {len(nova_tabela):,} linhas")
    

    logger.info(f"\nConcatenando {len(todas_tabelas)} tabelas...")
    tabela_final = pa.concat_tables(todas_tabelas)
    
    logger.info("=" * 60)
    logger.success(f"PROCESSAMENTO CONCLUÍDO!")
    logger.info(f"Total de linhas na tabela unificada: {len(tabela_final):,}")
    logger.info("=" * 60)
    
    return tabela_final


def salvar_tabela_parquet(tabela, caminho_arquivo):
    """
    Salva uma tabela PyArrow em formato Parquet.
    
    Args:
        tabela: Tabela PyArrow a ser salva
        caminho_arquivo: Caminho onde o arquivo Parquet será salvo (str ou Path)
    """
    caminho_arquivo = Path(caminho_arquivo)
    caminho_arquivo.parent.mkdir(parents=True, exist_ok=True)
    
    if tabela is None or len(tabela) == 0:
        logger.warning("Tabela vazia ou None, não será salva.")
        return
    
    logger.info(f"Salvando tabela em Parquet: {caminho_arquivo}")
    inicio = time.time()
    
    pq.write_table(
        tabela,
        str(caminho_arquivo),
        compression='snappy',
        use_dictionary=True,
        write_statistics=True,
        row_group_size=1000000
    )
    
    tempo_salvamento = time.time() - inicio
    tamanho_arquivo = caminho_arquivo.stat().st_size / (1024 * 1024)
    
    logger.success(f"Arquivo Parquet salvo com sucesso!")
    logger.info(f"Tempo de salvamento: {tempo_salvamento:.2f} segundos")
    logger.info(f"Tamanho do arquivo: {tamanho_arquivo:.2f} MB")
    logger.info(f"Total de linhas: {len(tabela):,}")


# if __name__ == '__main__':
#     logger.remove()
#     logger.add(
#         sink=lambda msg: print(msg, end=""),
#         format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
#         level="INFO",
#         colorize=True
#     )


#     script_dir = Path(__file__).parent.resolve()
    

#     diretorio_parquet = script_dir
#     tabela_unificada = processar_arquivos_e_gerar_tabela(diretorio_parquet)
    
#     if tabela_unificada is not None:

#         caminho_parquet = script_dir / "tabela_unificada.parquet"
#         salvar_tabela_parquet(tabela_unificada, caminho_parquet)
        

#         print("\n" + "=" * 80)
#         print(f"Total de linhas na tabela completa: {len(tabela_unificada):,}")
#         print(f"Arquivo Parquet salvo em: {caminho_parquet}")
#         print("=" * 80)
