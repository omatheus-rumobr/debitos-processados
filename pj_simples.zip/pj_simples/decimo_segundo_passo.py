from pathlib import Path
import pyarrow.parquet as pq
from datetime import date
from sqlalchemy import Column, Integer, String, Date
from sqlalchemy.orm import Session
from db import DatabaseManager, DatabaseConfig, Base
from loguru import logger


# Modelo SQLAlchemy para a tabela base_simples
class BaseSimples(Base):
    """Modelo para a tabela base_simples"""
    __tablename__ = 'base_simples'
    
    id = Column(Integer, primary_key=True, index=True)
    cnpj_raiz = Column(String(8), index=True, nullable=False)
    dt_consulta = Column(Date, nullable=True)
    # Adicione outros campos conforme necessário
    
    def __repr__(self):
        return f"<BaseSimples(id={self.id}, cnpj_raiz={self.cnpj_raiz}, dt_consulta={self.dt_consulta})>"


def atualizar_dt_consulta(script_dir, dt_consulta=None):
    """
    Atualiza o campo dt_consulta na tabela base_simples com base nos registros do arquivo parquet.
    
    Args:
        script_dir: Diretório do script (Path)
        dt_consulta: Data de consulta (date). Se None, usa a data atual.
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    if dt_consulta is None:
        dt_consulta = date.today()
    
    arquivo_parquet = script_dir / "correspondentes_encontrados.parquet"
    session = None
    
    try:
        if not arquivo_parquet.exists():
            logger.error(f"Arquivo '{arquivo_parquet}' não encontrado!")
            return False
        
        # Configurar conexão com banco de dados
        db_config = DatabaseConfig()
        db_manager = DatabaseManager(config=db_config, echo=False)
        session = db_manager.get_session()
        
        # Ler o arquivo parquet usando pyarrow
        logger.info(f"Lendo arquivo: {arquivo_parquet}")
        table = pq.read_table(arquivo_parquet)
        df = table.to_pandas()
        
        logger.info(f"Total de registros no arquivo: {len(df):,}")
        
        # Obter CRUD para BaseSimples
        base_simples_crud = db_manager.get_crud(BaseSimples, session)
        
        atualizados = 0
        nao_encontrados = 0
        
        # Processar cada registro
        for idx, row in df.iterrows():
            cnpj_raiz = str(row['f0']).strip()
            
            # Buscar registro na tabela base_simples pelo cnpj_raiz
            registro = base_simples_crud.get_by(cnpj_raiz=cnpj_raiz)
            
            if registro:
                # Atualizar apenas o campo dt_consulta
                base_simples_crud.update(registro.id, dt_consulta=dt_consulta)
                atualizados += 1
                
                if atualizados % 100 == 0:
                    logger.info(f"Atualizados: {atualizados:,} registros...")
            else:
                nao_encontrados += 1
                if nao_encontrados <= 10:  # Limitar avisos para não poluir o log
                    logger.warning(f"CNPJ raiz {cnpj_raiz} não encontrado na tabela base_simples")
        
        # Commit final
        session.commit()
        
        logger.info("\n" + "=" * 60)
        logger.info("Processamento concluído!")
        logger.info(f"Total de registros processados: {len(df):,}")
        logger.info(f"Registros atualizados: {atualizados:,}")
        logger.info(f"Registros não encontrados: {nao_encontrados:,}")
        logger.info(f"Data de consulta aplicada: {dt_consulta}")
        logger.info("=" * 60)
        
        return True
        
    except Exception as e:
        if session:
            session.rollback()
        logger.exception(f"Erro durante o processamento: {e}")
        return False
    finally:
        if session:
            session.close()
    