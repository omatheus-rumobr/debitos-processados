from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
from loguru import logger


def encontrar_correspondentes(script_dir):
    """
    Encontra correspondentes entre o arquivo filtrado e os arquivos da pasta exportados_base_simples.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    try:
        arquivo_filtrado = script_dir / "nao_correspondentes_filtrado.parquet"
        pasta_exportados = script_dir / "exportados_base_simples"
        arquivo_saida = script_dir / "correspondentes_encontrados.parquet"
        
        if not arquivo_filtrado.exists():
            logger.error(f"Arquivo '{arquivo_filtrado}' não encontrado!")
            return False
        
        if not pasta_exportados.exists():
            logger.error(f"Pasta '{pasta_exportados}' não encontrada!")
            return False
        
        # Ler a primeira coluna (f0) do arquivo filtrado
        logger.info(f"Lendo coluna f0 do arquivo: {arquivo_filtrado}")
        table_filtrado = pq.read_table(arquivo_filtrado, columns=['f0'])
        df_f0 = table_filtrado.to_pandas()
        logger.info(f"Total de valores únicos em f0: {len(df_f0):,}")
        
        # Ler todos os arquivos parquet da pasta exportados_base_simples e extrair cnpj_raiz
        logger.info(f"\nLendo arquivos parquet de: {pasta_exportados}")
        arquivos_parquet = sorted(pasta_exportados.glob("*.parquet"))
        
        if not arquivos_parquet:
            logger.error(f"Nenhum arquivo .parquet encontrado na pasta '{pasta_exportados}'!")
            return False
        
        logger.info(f"Total de arquivos encontrados: {len(arquivos_parquet)}")
        
        cnpj_raiz_list = []
        for arquivo in arquivos_parquet:
            logger.info(f"  Processando: {arquivo.name}")
            table = pq.read_table(arquivo, columns=['cnpj_raiz'])
            df_temp = table.to_pandas()
            cnpj_raiz_list.append(df_temp)
        
        # Combinar todos os cnpj_raiz em um único DataFrame
        df_cnpj_raiz = pd.concat(cnpj_raiz_list, ignore_index=True)
        df_cnpj_raiz = df_cnpj_raiz.drop_duplicates()
        logger.info(f"\nTotal de valores únicos em cnpj_raiz: {len(df_cnpj_raiz):,}")
        
        # Encontrar os valores que estão presentes em ambos (f0 e cnpj_raiz)
        logger.info("\nComparando valores...")
        # Renomear f0 para facilitar o merge
        df_f0_renamed = df_f0.rename(columns={'f0': 'cnpj_raiz'})
        
        # Fazer inner join para encontrar apenas os que estão presentes em ambos
        df_correspondentes = df_f0_renamed.merge(df_cnpj_raiz, on='cnpj_raiz', how='inner')
        logger.info(f"Total de valores presentes em ambos: {len(df_correspondentes):,}")
        
        # Ler o arquivo filtrado completo para manter todas as colunas dos registros correspondentes
        logger.info(f"\nLendo arquivo completo para extrair registros correspondentes...")
        table_completo = pq.read_table(arquivo_filtrado)
        df_completo = table_completo.to_pandas()
        
        # Filtrar apenas os registros onde f0 está na lista de correspondentes
        valores_correspondentes = set(df_correspondentes['cnpj_raiz'])
        df_resultado = df_completo[df_completo['f0'].isin(valores_correspondentes)]
        
        logger.info(f"Total de registros no arquivo final: {len(df_resultado):,}")
        
        # Salvar o arquivo resultado
        logger.info(f"\nSalvando arquivo resultado: {arquivo_saida}")
        df_resultado.to_parquet(arquivo_saida, index=False)
        
        logger.success("\nProcessamento concluído!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro ao encontrar correspondentes: {e}")
        return False
