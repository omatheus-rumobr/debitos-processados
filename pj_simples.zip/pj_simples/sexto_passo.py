import pyarrow.parquet as pq
import pyarrow as pa
from loguru import logger
from collections import defaultdict
from pathlib import Path


logger.remove()
logger.add(
    sink=lambda msg: print(msg, end=""),
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
    colorize=True
)


def extrair_ano_da_data(valor_data):
    """
    Extrai o ano de um valor de data no formato YYYYMMDD.
    
    Args:
        valor_data: Valor da data como int ou string (ex: 20070701)
        
    Returns:
        int: Ano extraído (ex: 2007) ou None se não for possível extrair
    """
    if valor_data is None:
        return None
    
    try:
        data_str = str(valor_data)

        if len(data_str) >= 4:
            ano = int(data_str[:4])
            return ano
        else:
            return None
    except (ValueError, TypeError):
        return None


def separar_por_ano(caminho_parquet, diretorio_saida=None):
    """
    Lê um arquivo Parquet e separa os dados em grupos por ano baseado na coluna 4.
    Cria um arquivo Parquet para cada ano encontrado.
    
    Args:
        caminho_parquet: Caminho para o arquivo Parquet (str ou Path)
        diretorio_saida: Diretório onde os arquivos Parquet serão salvos (str ou Path, padrão: mesmo diretório do arquivo Parquet)
    """
    caminho_parquet = Path(caminho_parquet)
    
    if diretorio_saida is None:
        diretorio_saida = caminho_parquet.parent
    else:
        diretorio_saida = Path(diretorio_saida)
    
    logger.info("=" * 60)
    logger.info("INICIANDO SEPARAÇÃO POR ANO")
    logger.info("=" * 60)
    
    parquet_file = pq.ParquetFile(str(caminho_parquet))
    num_row_groups = parquet_file.metadata.num_row_groups
    total_linhas = parquet_file.metadata.num_rows
    
    logger.info(f"Processando arquivo Parquet com {total_linhas:,} linhas em {num_row_groups} grupos...")
    

    tabelas_por_ano = defaultdict(list)
    
    linhas_processadas = 0
    indice_coluna_data = 3
    
    for i in range(num_row_groups):
        lote = parquet_file.read_row_group(i, use_threads=True)
        
        coluna_data = lote.column(indice_coluna_data)
        valores_data = coluna_data.to_pylist()
        
        indices_por_ano = defaultdict(list)
        
        for j, valor_data in enumerate(valores_data):
            ano = extrair_ano_da_data(valor_data)
            if ano is not None:
                indices_por_ano[ano].append(j)

        for ano, indices in indices_por_ano.items():
            lote_ano = lote.take(pa.array(indices))
            tabelas_por_ano[ano].append(lote_ano)
        
        linhas_processadas += len(lote)

        if (i + 1) % 10 == 0 or (i + 1) == num_row_groups:
            percentual = (linhas_processadas / total_linhas) * 100
            anos_encontrados = len(tabelas_por_ano)
            logger.info(f"Progresso: {i + 1}/{num_row_groups} grupos ({percentual:.1f}%) - "
                       f"Anos encontrados: {anos_encontrados}")
    
    logger.info(f"Total de linhas processadas: {linhas_processadas:,}")
    logger.info(f"Total de anos distintos encontrados: {len(tabelas_por_ano)}")

    diretorio_saida.mkdir(parents=True, exist_ok=True)

    logger.info("\nSalvando arquivos Parquet por ano...")
    for ano in sorted(tabelas_por_ano.keys()):
        tabela_ano = pa.concat_tables(tabelas_por_ano[ano])
        num_linhas = len(tabela_ano)
 
        nome_arquivo = f"dados_{ano}.parquet"
        caminho_arquivo = diretorio_saida / nome_arquivo
        
        logger.info(f"Salvando ano {ano}: {num_linhas:,} linhas em '{caminho_arquivo}'...")
        pq.write_table(tabela_ano, str(caminho_arquivo), compression='snappy')
        logger.success(f"Arquivo '{nome_arquivo}' salvo com {num_linhas:,} linhas.")
    
    logger.info("=" * 60)
    logger.success("PROCESSO CONCLUÍDO COM SUCESSO!")
    logger.info("=" * 60)
    

    logger.info("\nResumo dos arquivos criados:")
    for ano in sorted(tabelas_por_ano.keys()):
        tabela_ano = pa.concat_tables(tabelas_por_ano[ano])
        logger.info(f"  - dados_{ano}.parquet: {len(tabela_ano):,} linhas")


# if __name__ == '__main__':
#     script_dir = Path(__file__).parent.resolve()

#     arquivo_parquet = script_dir / "nao_correspondentes.parquet"

#     diretorio_saida = script_dir
    
#     separar_por_ano(str(arquivo_parquet), str(diretorio_saida))
