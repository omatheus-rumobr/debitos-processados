"""
Módulo CRUD com SQLAlchemy para PostgreSQL
Fornece uma classe base genérica para operações CRUD e configuração de conexão com banco de dados.
"""

from sqlalchemy import create_engine, Column, Integer, String, Date, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError
from typing import Optional, List, Dict, Any, Type, TypeVar, Generic
from datetime import datetime
import os
from loguru import logger
from dotenv import load_dotenv


load_dotenv()

# Tipo genérico para modelos
ModelType = TypeVar('ModelType')

# Base para modelos SQLAlchemy
Base = declarative_base()


class DatabaseConfig:
    """Configuração de conexão com o banco de dados PostgreSQL"""
    
    def __init__(
        self,
        host: str = None,
        port: int = None,
        database: str = None,
        username: str = None,
        password: str = None,
        connection_string: str = None
    ):
        """
        Inicializa a configuração do banco de dados.
        
        Args:
            host: Host do PostgreSQL (padrão: localhost)
            port: Porta do PostgreSQL (padrão: 5432)
            database: Nome do banco de dados
            username: Usuário do banco de dados
            password: Senha do banco de dados
            connection_string: String de conexão completa (opcional, sobrescreve outros parâmetros)
        """
        if connection_string:
            self.connection_string = connection_string
        else:
            # Usa variáveis de ambiente se não fornecidas
            self.host = host or os.getenv('DB_HOST', 'localhost')
            self.port = port or int(os.getenv('DB_PORT', 5432))
            self.database = database or os.getenv('DB_NAME', 'periodos_db')
            self.username = username or os.getenv('DB_USER', 'postgres')
            self.password = password or os.getenv('DB_PASSWORD', 'postgres')
            
            # Cria string de conexão
            self.connection_string = (
                f"postgresql://{self.username}:{self.password}"
                f"@{self.host}:{self.port}/{self.database}"
            )
    
    def get_engine(self, echo: bool = False):
        """
        Cria e retorna uma engine SQLAlchemy.
        
        Args:
            echo: Se True, imprime todas as queries SQL (útil para debug)
            
        Returns:
            Engine SQLAlchemy configurada
        """
        return create_engine(
            self.connection_string,
            echo=echo,
            pool_pre_ping=True,  # Verifica conexões antes de usar
            pool_size=10,  # Tamanho do pool de conexões
            max_overflow=20  # Máximo de conexões além do pool_size
        )


class CRUDBase(Generic[ModelType]):
    """Classe base genérica para operações CRUD"""
    
    def __init__(self, model: Type[ModelType], session: Session):
        """
        Inicializa o CRUD com um modelo e sessão.
        
        Args:
            model: Classe do modelo SQLAlchemy
            session: Sessão SQLAlchemy
        """
        self.model = model
        self.session = session
    
    def create(self, **kwargs) -> ModelType:
        """
        Cria um novo registro no banco de dados.
        
        Args:
            **kwargs: Campos do modelo a serem criados
            
        Returns:
            Instância do modelo criado
            
        Raises:
            SQLAlchemyError: Em caso de erro na operação
        """
        try:
            instance = self.model(**kwargs)
            self.session.add(instance)
            self.session.commit()
            self.session.refresh(instance)
            logger.info(f"Registro criado: {instance}")
            return instance
        except SQLAlchemyError as e:
            self.session.rollback()
            logger.error(f"Erro ao criar registro: {e}")
            raise
    
    def get(self, id: int) -> Optional[ModelType]:
        """
        Busca um registro por ID.
        
        Args:
            id: ID do registro
            
        Returns:
            Instância do modelo ou None se não encontrado
        """
        try:
            return self.session.query(self.model).filter(self.model.id == id).first()
        except SQLAlchemyError as e:
            logger.error(f"Erro ao buscar registro por ID {id}: {e}")
            raise
    
    def get_by(self, **kwargs) -> Optional[ModelType]:
        """
        Busca um registro por critérios específicos.
        
        Args:
            **kwargs: Critérios de busca (ex: cnpj='12345678000100')
            
        Returns:
            Instância do modelo ou None se não encontrado
        """
        try:
            return self.session.query(self.model).filter_by(**kwargs).first()
        except SQLAlchemyError as e:
            logger.error(f"Erro ao buscar registro: {e}")
            raise
    
    def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        **filters
    ) -> List[ModelType]:
        """
        Busca múltiplos registros com filtros opcionais.
        
        Args:
            skip: Número de registros a pular (para paginação)
            limit: Número máximo de registros a retornar
            **filters: Filtros adicionais (ex: cnpj_raiz='12345678')
            
        Returns:
            Lista de instâncias do modelo
        """
        try:
            query = self.session.query(self.model)
            
            # Aplica filtros
            for key, value in filters.items():
                if hasattr(self.model, key):
                    query = query.filter(getattr(self.model, key) == value)
            
            return query.offset(skip).limit(limit).all()
        except SQLAlchemyError as e:
            logger.error(f"Erro ao buscar registros: {e}")
            raise
    
    def update(self, id: int, **kwargs) -> Optional[ModelType]:
        """
        Atualiza um registro existente.
        
        Args:
            id: ID do registro a ser atualizado
            **kwargs: Campos a serem atualizados
            
        Returns:
            Instância atualizada do modelo ou None se não encontrado
            
        Raises:
            SQLAlchemyError: Em caso de erro na operação
        """
        try:
            instance = self.get(id)
            if not instance:
                logger.warning(f"Registro com ID {id} não encontrado para atualização")
                return None
            
            for key, value in kwargs.items():
                if hasattr(instance, key):
                    setattr(instance, key, value)
            
            self.session.commit()
            self.session.refresh(instance)
            logger.info(f"Registro atualizado: {instance}")
            return instance
        except SQLAlchemyError as e:
            self.session.rollback()
            logger.error(f"Erro ao atualizar registro: {e}")
            raise
    
    def delete(self, id: int) -> bool:
        """
        Deleta um registro do banco de dados.
        
        Args:
            id: ID do registro a ser deletado
            
        Returns:
            True se deletado com sucesso, False se não encontrado
            
        Raises:
            SQLAlchemyError: Em caso de erro na operação
        """
        try:
            instance = self.get(id)
            if not instance:
                logger.warning(f"Registro com ID {id} não encontrado para deleção")
                return False
            
            self.session.delete(instance)
            self.session.commit()
            logger.info(f"Registro deletado: ID {id}")
            return True
        except SQLAlchemyError as e:
            self.session.rollback()
            logger.error(f"Erro ao deletar registro: {e}")
            raise
    
    def count(self, **filters) -> int:
        """
        Conta o número de registros que correspondem aos filtros.
        
        Args:
            **filters: Filtros opcionais
            
        Returns:
            Número de registros
        """
        try:
            query = self.session.query(self.model)
            
            for key, value in filters.items():
                if hasattr(self.model, key):
                    query = query.filter(getattr(self.model, key) == value)
            
            return query.count()
        except SQLAlchemyError as e:
            logger.error(f"Erro ao contar registros: {e}")
            raise
    
    def bulk_create(self, instances: List[Dict[str, Any]]) -> List[ModelType]:
        """
        Cria múltiplos registros de uma vez (mais eficiente).
        
        Args:
            instances: Lista de dicionários com dados dos registros
            
        Returns:
            Lista de instâncias criadas
            
        Raises:
            SQLAlchemyError: Em caso de erro na operação
        """
        try:
            objects = [self.model(**data) for data in instances]
            self.session.bulk_save_objects(objects)
            self.session.commit()
            logger.info(f"{len(objects)} registros criados em bulk")
            return objects
        except SQLAlchemyError as e:
            self.session.rollback()
            logger.error(f"Erro ao criar registros em bulk: {e}")
            raise


class DatabaseManager:
    """Gerenciador de banco de dados com sessão e operações CRUD"""
    
    def __init__(self, config: DatabaseConfig = None, echo: bool = False):
        """
        Inicializa o gerenciador de banco de dados.
        
        Args:
            config: Configuração do banco de dados (usa padrão se None)
            echo: Se True, imprime queries SQL
        """
        self.config = config or DatabaseConfig()
        self.engine = self.config.get_engine(echo=echo)
        self.SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine
        )
    
    def create_tables(self):
        """Cria todas as tabelas definidas nos modelos"""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Tabelas criadas com sucesso")
        except SQLAlchemyError as e:
            logger.error(f"Erro ao criar tabelas: {e}")
            raise
    
    def drop_tables(self):
        """Remove todas as tabelas (CUIDADO: apaga todos os dados!)"""
        try:
            Base.metadata.drop_all(bind=self.engine)
            logger.warning("Todas as tabelas foram removidas")
        except SQLAlchemyError as e:
            logger.error(f"Erro ao remover tabelas: {e}")
            raise
    
    def get_session(self) -> Session:
        """
        Retorna uma nova sessão do banco de dados.
        
        Returns:
            Sessão SQLAlchemy
        """
        return self.SessionLocal()
    
    def get_crud(self, model: Type[ModelType], session: Session = None) -> CRUDBase[ModelType]:
        """
        Retorna uma instância CRUD para um modelo específico.
        
        Args:
            model: Classe do modelo SQLAlchemy
            session: Sessão (cria nova se None)
            
        Returns:
            Instância CRUDBase configurada
        """
        if session is None:
            session = self.get_session()
        return CRUDBase(model, session)


# Exemplo de modelo para CNPJ (baseado na estrutura do projeto)
class CNPJModel(Base):
    """Modelo de exemplo para dados de CNPJ"""
    __tablename__ = 'cnpj_registros'
    
    id = Column(Integer, primary_key=True, index=True)
    cnpj = Column(String(14), unique=True, index=True, nullable=False)
    cnpj_raiz = Column(String(8), index=True, nullable=False)
    entrada = Column(Date, nullable=True)
    saida = Column(Date, nullable=True)
    motivo = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<CNPJModel(id={self.id}, cnpj={self.cnpj}, cnpj_raiz={self.cnpj_raiz})>"


# Exemplo de uso
if __name__ == "__main__":
    # Configuração do banco de dados
    db_config = DatabaseConfig(
        host='localhost',
        port=5432,
        database='periodos_db',
        username='postgres',
        password='postgres'
    )
    
    # Inicializa o gerenciador
    db_manager = DatabaseManager(config=db_config, echo=True)
    
    # Cria as tabelas
    db_manager.create_tables()
    
    # Obtém uma sessão
    session = db_manager.get_session()
    
    try:
        # Obtém CRUD para o modelo CNPJ
        cnpj_crud = db_manager.get_crud(CNPJModel, session)
        
        # Exemplo: Criar um registro
        novo_cnpj = cnpj_crud.create(
            cnpj='12345678000100',
            cnpj_raiz='12345678',
            entrada=datetime(2023, 1, 1).date(),
            motivo='Inclusão'
        )
        print(f"Criado: {novo_cnpj}")
        
        # Exemplo: Buscar por ID
        encontrado = cnpj_crud.get(novo_cnpj.id)
        print(f"Encontrado: {encontrado}")
        
        # Exemplo: Buscar por CNPJ
        encontrado_cnpj = cnpj_crud.get_by(cnpj='12345678000100')
        print(f"Encontrado por CNPJ: {encontrado_cnpj}")
        
        # Exemplo: Listar todos
        todos = cnpj_crud.get_all(limit=10)
        print(f"Total encontrados: {len(todos)}")
        
        # Exemplo: Atualizar
        atualizado = cnpj_crud.update(
            novo_cnpj.id,
            motivo='Atualizado',
            saida=datetime(2023, 12, 31).date()
        )
        print(f"Atualizado: {atualizado}")
        
        # Exemplo: Contar registros
        total = cnpj_crud.count()
        print(f"Total de registros: {total}")
        
        # Exemplo: Criar múltiplos registros
        registros_bulk = [
            {
                'cnpj': '11111111000111',
                'cnpj_raiz': '11111111',
                'entrada': datetime(2023, 1, 1).date(),
                'motivo': 'Inclusão'
            },
            {
                'cnpj': '22222222000222',
                'cnpj_raiz': '22222222',
                'entrada': datetime(2023, 2, 1).date(),
                'motivo': 'Inclusão'
            }
        ]
        criados = cnpj_crud.bulk_create(registros_bulk)
        print(f"Criados em bulk: {len(criados)}")
        
    except Exception as e:
        logger.error(f"Erro: {e}")
        session.rollback()
    finally:
        session.close()
