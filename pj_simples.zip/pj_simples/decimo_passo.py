from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq
from loguru import logger


def filtrar_nao_correspondentes(script_dir):
    """
    Filtra o arquivo nao_correspondentes.parquet aplicando condições específicas.
    
    Args:
        script_dir: Diretório do script (Path)
        
    Returns:
        bool: True se sucesso, False caso contrário
    """
    try:
        arquivo_entrada = script_dir / "nao_correspondentes.parquet"
        arquivo_saida = script_dir / "nao_correspondentes_filtrado.parquet"
        
        if not arquivo_entrada.exists():
            logger.error(f"Arquivo '{arquivo_entrada}' não encontrado!")
            return False
        
        logger.info(f"Lendo arquivo: {arquivo_entrada}")
        table = pq.read_table(arquivo_entrada)
        df = table.to_pandas()
        
        logger.info(f"Total de registros antes do filtro: {len(df):,}")
        
        df_filtrado = df[(df['f1'] == 'N') & (df['f2'] == df['f3'])]
        
        logger.info(f"Total de registros após o filtro: {len(df_filtrado):,}")
        
        logger.info(f"Salvando arquivo filtrado: {arquivo_saida}")
        df_filtrado.to_parquet(arquivo_saida, index=False)
        
        logger.success("Processamento concluído!")
        return True
        
    except Exception as e:
        logger.exception(f"Erro ao filtrar não correspondentes: {e}")
        return False

