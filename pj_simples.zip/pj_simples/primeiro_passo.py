"""
Script para exportar dados da coluna cnpj_raiz para arquivos Parquet usando psycopg2 e PyArrow
Processa em lotes de 1 milhão de linhas
"""

import psycopg2
import os
from dotenv import load_dotenv
from loguru import logger
from tqdm import tqdm
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path


load_dotenv()


DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME', 'periodos_db')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'postgres')


TABELA = 'base_simples_periodos'
COLUNA = 'cnpj_raiz'
DIRETORIO_EXPORTACAO = 'exportados'
PREFIXO_ARQUIVO = 'cnpj_raiz_lote'
TAMANHO_LOTE = 1_000_000


logger.remove()
logger.add(
    sink=lambda msg: print(msg, end=""),
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
    colorize=True
)


def exportar_cnpj_raiz_para_parquet():
    """
    Exporta os dados da coluna cnpj_raiz da tabela para arquivos Parquet em lotes.
    Processa em lotes de 1 milhão de linhas e salva cada lote em um arquivo Parquet separado.
    """
    try:
        # Verificar se o diretório já existe e contém arquivos
        diretorio_export = Path(DIRETORIO_EXPORTACAO)
        
        if diretorio_export.exists() and diretorio_export.is_dir():
            # Verificar se há arquivos Parquet com o prefixo esperado
            arquivos_existentes = list(diretorio_export.glob(f"{PREFIXO_ARQUIVO}_*.parquet"))
            
            if arquivos_existentes:
                logger.warning("=" * 60)
                logger.warning(f"Diretório '{DIRETORIO_EXPORTACAO}' já existe e contém {len(arquivos_existentes)} arquivo(s) Parquet!")
                logger.warning(f"Diretório: {diretorio_export.absolute()}")
                logger.warning("Exportação não será executada para evitar sobrescrever arquivos existentes.")
                logger.warning("=" * 60)
                return
        
        # Criar diretório se não existir
        diretorio_export.mkdir(exist_ok=True)
        logger.info(f"Diretório de exportação: {diretorio_export.absolute()}")
        

        logger.info(f"Conectando ao banco de dados {DB_NAME} em {DB_HOST}:{DB_PORT}...")
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        logger.success("Conexão estabelecida com sucesso!")
        

        cursor = conn.cursor()
        

        logger.info("Contando total de registros...")
        cursor.execute(f"SELECT COUNT(*) FROM {TABELA} WHERE {COLUNA} IS NOT NULL")
        total_registros = cursor.fetchone()[0]
        
        logger.info(f"Total de registros encontrados: {total_registros:,}")
        
        if total_registros == 0:
            logger.warning("Nenhum registro encontrado para exportar!")
            cursor.close()
            conn.close()
            return
        

        num_lotes = (total_registros + TAMANHO_LOTE - 1) // TAMANHO_LOTE
        logger.info(f"Processando em {num_lotes} lote(s) de até {TAMANHO_LOTE:,} registros cada")
        

        lote_atual = 1
        total_exportado = 0
        id_inicio = 0
        

        pbar_geral = tqdm(total=total_registros, desc="Progresso Total", unit=" registros", ncols=100)
        
        while True:

            sql_query = f"""
                SELECT id, {COLUNA} 
                FROM {TABELA} 
                WHERE {COLUNA} IS NOT NULL AND id > %s 
                ORDER BY id 
                LIMIT %s
            """
            
            logger.info(f"Processando lote {lote_atual}/{num_lotes} (a partir do id {id_inicio})...")
            logger.debug(f"Query: SELECT id, {COLUNA} FROM {TABELA} WHERE {COLUNA} IS NOT NULL AND id > {id_inicio} ORDER BY id LIMIT {TAMANHO_LOTE}")
            
            cursor.execute(sql_query, (id_inicio, TAMANHO_LOTE))
            lote_dados = cursor.fetchall()
            
            if not lote_dados:
                break
            

            valores_cnpj_raiz = [linha[1] for linha in lote_dados]
            tamanho_lote_atual = len(valores_cnpj_raiz)
            

            id_inicio = lote_dados[-1][0]
            

            tabela_pa = pa.table({COLUNA: valores_cnpj_raiz})
            

            nome_arquivo = f"{PREFIXO_ARQUIVO}_{lote_atual:04d}.parquet"
            caminho_arquivo = diretorio_export / nome_arquivo
            

            logger.info(f"Salvando lote {lote_atual} ({tamanho_lote_atual:,} registros) em {nome_arquivo}...")
            pq.write_table(
                tabela_pa,
                caminho_arquivo,
                compression='snappy',
                use_dictionary=True,
                write_statistics=True
            )
            
            total_exportado += tamanho_lote_atual
            pbar_geral.update(tamanho_lote_atual)
            
            logger.success(f"Lote {lote_atual} salvo com sucesso! ({tamanho_lote_atual:,} registros)")
            logger.info(f"Total exportado até agora: {total_exportado:,}/{total_registros:,}")
            logger.info(f"Próximo lote começará do id: {id_inicio}")
            
            lote_atual += 1
            

            if tamanho_lote_atual < TAMANHO_LOTE:
                break
        
        pbar_geral.close()
        
        logger.success("=" * 60)
        logger.success("Exportação concluída com sucesso!")
        logger.info(f"Diretório de exportação: {diretorio_export.absolute()}")
        logger.info(f"Total de arquivos Parquet criados: {lote_atual - 1}")
        logger.info(f"Total de registros exportados: {total_exportado:,}")
        logger.success("=" * 60)
        

        cursor.close()
        conn.close()
        logger.info("Conexão com o banco de dados fechada.")
        
    except psycopg2.Error as e:
        logger.error(f"Erro ao conectar ou executar query no PostgreSQL: {e}")
        raise
    except Exception as e:
        logger.error(f"Erro inesperado: {e}")
        raise


# if __name__ == "__main__":
#     exportar_cnpj_raiz_para_parquet()
