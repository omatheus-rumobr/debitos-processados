import pyarrow.parquet as pq
import pyarrow.csv as csv
from loguru import logger
import pyarrow as pa
from pathlib import Path
import shutil


logger.remove()
logger.add(
    sink=lambda msg: print(msg, end=""),
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
    level="INFO",
    colorize=True
)


def ler_csv_otimizado(caminho_csv, delimiter=',', tem_cabecalho=True):
    """
    Lê um arquivo CSV de forma otimizada usando PyArrow.
    Ignora as colunas 'id' e 'created_at' se existirem.
    Garante que a primeira coluna (f0) seja tratada como string para preservar zeros à esquerda.
    
    Args:
        caminho_csv: Caminho para o arquivo CSV (str ou Path)
        delimiter: Delimitador do CSV (padrão: ',')
        tem_cabecalho: Se True, assume que o CSV tem cabeçalho. Se False, gera nomes automáticos (f0, f1, etc.)
        
    Returns:
        pyarrow.Table: Tabela PyArrow com os dados (sem as colunas id e created_at se existirem)
    """
    caminho_csv = Path(caminho_csv)
    parse_options = csv.ParseOptions(
        delimiter=delimiter,
        quote_char='"',
        escape_char=None,
        double_quote=True,
        newlines_in_values=False,
        ignore_empty_lines=True
    )
    
    convert_options = csv.ConvertOptions(
        strings_can_be_null=True,
        null_values=['', 'NULL', 'null', 'None'],
        auto_dict_encode=True,
        auto_dict_max_cardinality=0.8,
        check_utf8=False,
        # Desabilitar conversão automática de tipos para preservar zeros à esquerda
        # A primeira coluna será convertida para string explicitamente depois
        include_columns=None,
        column_types=None,
    )
    
    read_options = csv.ReadOptions(
        use_threads=True,
        block_size=10485760,
        skip_rows=0,
        column_names=None,
        autogenerate_column_names=not tem_cabecalho,
    )
    
    # Se não tem cabeçalho, a primeira coluna será 'f0', então podemos especificar o tipo diretamente
    # Se tem cabeçalho, precisamos ler primeiro para descobrir o nome
    if not tem_cabecalho:
        # Especificar que a primeira coluna (f0) deve ser string para preservar zeros à esquerda
        convert_options_with_types = csv.ConvertOptions(
            strings_can_be_null=True,
            null_values=['', 'NULL', 'null', 'None'],
            auto_dict_encode=True,
            auto_dict_max_cardinality=0.8,
            check_utf8=False,
            column_types={'f0': pa.string()},
        )
        tabela = csv.read_csv(
            str(caminho_csv),
            read_options=read_options,
            parse_options=parse_options,
            convert_options=convert_options_with_types
        )
    else:
        # Se tem cabeçalho, ler primeiro para descobrir o nome da primeira coluna
        tabela_temp = csv.read_csv(
            str(caminho_csv),
            read_options=read_options,
            parse_options=parse_options,
            convert_options=convert_options
        )
        
        # Descobrir o nome da primeira coluna e ler novamente com tipo especificado
        if len(tabela_temp.column_names) > 0:
            primeira_coluna_nome = tabela_temp.column_names[0]
            convert_options_with_types = csv.ConvertOptions(
                strings_can_be_null=True,
                null_values=['', 'NULL', 'null', 'None'],
                auto_dict_encode=True,
                auto_dict_max_cardinality=0.8,
                check_utf8=False,
                column_types={primeira_coluna_nome: pa.string()},
            )
            tabela = csv.read_csv(
                str(caminho_csv),
                read_options=read_options,
                parse_options=parse_options,
                convert_options=convert_options_with_types
            )
        else:
            tabela = tabela_temp

    colunas_para_remover = ['id', 'created_at']
    colunas_existentes = tabela.column_names
    colunas_para_remover_existentes = [col for col in colunas_para_remover if col in colunas_existentes]
    
    if colunas_para_remover_existentes:
        tabela = tabela.drop(colunas_para_remover_existentes)
    
    # Garantir que a primeira coluna seja string para preservar zeros à esquerda
    # (fallback caso a especificação de tipo não tenha funcionado)
    if len(tabela.column_names) > 0:
        primeira_coluna = tabela.column(0)
        
        # Se a primeira coluna não for string, converter para string
        if not pa.types.is_string(primeira_coluna.type):
            primeira_coluna_str = primeira_coluna.cast(pa.string())
            # Substituir a primeira coluna pela versão string
            colunas = list(tabela.columns)
            colunas[0] = primeira_coluna_str
            tabela = pa.table(colunas, names=tabela.column_names)
    
    return tabela


def ler_parquet_lotes(caminho_parquet, tamanho_lote: int = 1_000_000):
    """
    Lê um arquivo Parquet em lotes para otimizar o uso de memória.
    
    Args:
        caminho_parquet: Caminho para o arquivo Parquet (str ou Path)
        tamanho_lote: Número de linhas por lote (padrão: 1 milhão)
        
    Yields:
        pyarrow.Table: Lote de dados do Parquet
    """
    caminho_parquet = Path(caminho_parquet)
    parquet_file = pq.ParquetFile(str(caminho_parquet))
    num_linhas_total = parquet_file.metadata.num_rows
    
    for i in range(0, num_linhas_total, tamanho_lote):
        fim = min(i + tamanho_lote, num_linhas_total)
        lote = parquet_file.read_row_groups(
            range(i // parquet_file.metadata.num_rows * parquet_file.metadata.num_row_groups,
                  (fim // parquet_file.metadata.num_rows * parquet_file.metadata.num_row_groups) + 1),
            use_threads=True
        )

        if len(lote) > tamanho_lote:
            lote = lote.slice(i % tamanho_lote, tamanho_lote)
        
        yield lote


def extrair_cnpj_raiz_parquet_lotes(caminho_parquet, tamanho_lote: int = 1_000_000):
    """
    Extrai todos os valores de cnpj_raiz (primeira coluna) do arquivo Parquet
    lendo em lotes para otimizar memória. Processa todas as ocorrências, incluindo repetições.
    Mantém os valores como string para preservar zeros à esquerda.
    
    Args:
        caminho_parquet: Caminho para o arquivo Parquet (str ou Path)
        tamanho_lote: Número de linhas por lote (padrão: 1 milhão) - não usado, mantido para compatibilidade
        
    Returns:
        set: Conjunto com todos os valores distintos de cnpj_raiz do Parquet (como string) para verificação de existência
    """
    caminho_parquet = Path(caminho_parquet)
    parquet_file = pq.ParquetFile(str(caminho_parquet))
    cnpj_raiz_set = set()
    total_cnpjs_processados = 0
    
    num_row_groups = parquet_file.metadata.num_row_groups
    total_linhas = parquet_file.metadata.num_rows
    
    logger.info(f"Processando arquivo Parquet com {total_linhas:,} linhas em {num_row_groups} grupos...")
    
    linhas_processadas = 0
    for i in range(num_row_groups):
        lote = parquet_file.read_row_group(i, use_threads=True)

        primeira_coluna = lote.column(0)
        
        # Converter para string se não for já string, para preservar zeros à esquerda
        if not pa.types.is_string(primeira_coluna.type):
            primeira_coluna = primeira_coluna.cast(pa.string())

        valores = primeira_coluna.to_pylist()

        valores_normalizados = []
        for valor in valores:
            if valor is not None:
                # Manter como string para preservar zeros à esquerda
                valor_str = str(valor).strip()
                if valor_str:  # Só adicionar se não for string vazia
                    valores_normalizados.append(valor_str)
                    total_cnpjs_processados += 1
        
        cnpj_raiz_set.update(valores_normalizados)
        
        linhas_processadas += len(lote)

        if (i + 1) % 10 == 0 or (i + 1) == num_row_groups:
            percentual = (linhas_processadas / total_linhas) * 100
            logger.info(f"Progresso: {i + 1}/{num_row_groups} grupos ({percentual:.1f}%) - "
                       f"CNPJs processados: {total_cnpjs_processados:,} (valores distintos: {len(cnpj_raiz_set):,})")
    
    logger.info(f"Total de CNPJs raiz processados no Parquet: {total_cnpjs_processados:,} (valores distintos: {len(cnpj_raiz_set):,})")
    return cnpj_raiz_set


def extrair_cnpj_raiz_multiplos_parquets(lista_caminhos_parquet):
    """
    Extrai todos os valores de cnpj_raiz de múltiplos arquivos Parquet.
    
    Args:
        lista_caminhos_parquet: Lista de caminhos para arquivos Parquet (list de str ou Path)
        
    Returns:
        set: Conjunto com todos os valores distintos de cnpj_raiz de todos os Parquets combinados (como string)
    """
    cnpj_raiz_set_combinado = set()
    total_arquivos = len(lista_caminhos_parquet)
    
    logger.info(f"Processando {total_arquivos} arquivos Parquet...")
    
    for idx, caminho_parquet in enumerate(lista_caminhos_parquet, 1):
        logger.info(f"[{idx}/{total_arquivos}] Processando arquivo: {Path(caminho_parquet).name}")
        cnpj_raiz_set = extrair_cnpj_raiz_parquet_lotes(caminho_parquet)
        cnpj_raiz_set_combinado.update(cnpj_raiz_set)
        logger.info(f"CNPJs únicos acumulados até agora: {len(cnpj_raiz_set_combinado):,}")
    
    logger.info(f"Total de CNPJs raiz únicos de todos os Parquets: {len(cnpj_raiz_set_combinado):,}")
    return cnpj_raiz_set_combinado


def extrair_linhas_parquet_nao_correspondentes(caminho_parquet, cnpj_raiz_csv_set):
    """
    Extrai todas as linhas do Parquet cujo cnpj_raiz não está no CSV.
    Usa comparação de strings para preservar zeros à esquerda.
    
    Args:
        caminho_parquet: Caminho para o arquivo Parquet (str ou Path)
        cnpj_raiz_csv_set: Set com todos os cnpj_raiz do CSV (como string)
        
    Returns:
        pyarrow.Table: Tabela PyArrow com as linhas do Parquet que não estão no CSV
    """
    caminho_parquet = Path(caminho_parquet)
    parquet_file = pq.ParquetFile(str(caminho_parquet))
    num_row_groups = parquet_file.metadata.num_row_groups
    total_linhas = parquet_file.metadata.num_rows
    
    logger.info(f"Extraindo linhas do Parquet que não estão no CSV...")
    logger.info(f"Processando {total_linhas:,} linhas em {num_row_groups} grupos...")

    tabelas_filtradas = []
    linhas_processadas = 0
    total_linhas_filtradas = 0
    
    for i in range(num_row_groups):
        lote = parquet_file.read_row_group(i, use_threads=True)
        
        primeira_coluna = lote.column(0)
        
        # Converter para string se não for já string, para preservar zeros à esquerda
        if not pa.types.is_string(primeira_coluna.type):
            primeira_coluna = primeira_coluna.cast(pa.string())
            # Atualizar o lote com a coluna convertida
            colunas = list(lote.columns)
            colunas[0] = primeira_coluna
            lote = pa.table(colunas, names=lote.column_names)
        
        valores_cnpj_raiz = primeira_coluna.to_pylist()

        indices_para_manter = []
        for j, cnpj_raiz_valor in enumerate(valores_cnpj_raiz):
            if cnpj_raiz_valor is not None:
                # Manter como string para preservar zeros à esquerda
                cnpj_raiz_str = str(cnpj_raiz_valor).strip()
                if cnpj_raiz_str and cnpj_raiz_str not in cnpj_raiz_csv_set:
                    indices_para_manter.append(j)

        if indices_para_manter:
            lote_filtrado = lote.take(pa.array(indices_para_manter))
            tabelas_filtradas.append(lote_filtrado)
            total_linhas_filtradas += len(lote_filtrado)
        
        linhas_processadas += len(lote)
        
        if (i + 1) % 10 == 0 or (i + 1) == num_row_groups:
            percentual = (linhas_processadas / total_linhas) * 100
            logger.info(f"Progresso: {i + 1}/{num_row_groups} grupos ({percentual:.1f}%) - "
                       f"Linhas não correspondentes encontradas: {total_linhas_filtradas:,}")

    if tabelas_filtradas:
        tabela_final = pa.concat_tables(tabelas_filtradas)
        logger.info(f"Total de linhas do Parquet não correspondentes: {len(tabela_final):,}")
        return tabela_final
    else:
        logger.info("Nenhuma linha do Parquet não correspondente encontrada.")
        primeiro_lote = parquet_file.read_row_group(0)
        schema_vazio = primeiro_lote.schema

        arrays_vazios = [pa.array([], type=field.type) for field in schema_vazio]
        return pa.table(arrays_vazios, schema=schema_vazio)


def extrair_linhas_multiplos_parquets_nao_correspondentes(lista_caminhos_parquet, cnpj_raiz_csv_set):
    """
    Extrai todas as linhas de múltiplos arquivos Parquet cujo cnpj_raiz não está no CSV.
    
    Args:
        lista_caminhos_parquet: Lista de caminhos para arquivos Parquet (list de str ou Path)
        cnpj_raiz_csv_set: Set com todos os cnpj_raiz do CSV
        
    Returns:
        pyarrow.Table: Tabela PyArrow com as linhas de todos os Parquets que não estão no CSV
    """
    todas_tabelas_filtradas = []
    total_arquivos = len(lista_caminhos_parquet)
    
    logger.info(f"Extraindo linhas não correspondentes de {total_arquivos} arquivos Parquet...")
    
    for idx, caminho_parquet in enumerate(lista_caminhos_parquet, 1):
        logger.info(f"[{idx}/{total_arquivos}] Processando arquivo: {Path(caminho_parquet).name}")
        tabela_filtrada = extrair_linhas_parquet_nao_correspondentes(caminho_parquet, cnpj_raiz_csv_set)
        if len(tabela_filtrada) > 0:
            todas_tabelas_filtradas.append(tabela_filtrada)
            logger.info(f"Linhas não correspondentes encontradas neste arquivo: {len(tabela_filtrada):,}")
    
    if todas_tabelas_filtradas:
        tabela_final = pa.concat_tables(todas_tabelas_filtradas)
        logger.info(f"Total de linhas não correspondentes de todos os Parquets: {len(tabela_final):,}")
        return tabela_final
    else:
        logger.info("Nenhuma linha não correspondente encontrada em nenhum Parquet.")
        if lista_caminhos_parquet:
            primeiro_parquet = pq.ParquetFile(str(lista_caminhos_parquet[0]))
            primeiro_lote = primeiro_parquet.read_row_group(0)
            schema_vazio = primeiro_lote.schema

            arrays_vazios = [pa.array([], type=field.type) for field in schema_vazio]
            return pa.table(arrays_vazios, schema=schema_vazio)
        else:
            return None


def salvar_parquet_nao_correspondentes(tabela, caminho_arquivo):
    """
    Salva uma tabela PyArrow em um arquivo Parquet.
    
    Args:
        tabela: Tabela PyArrow com os dados a serem salvos
        caminho_arquivo: Caminho do arquivo de saída Parquet (str ou Path)
    """
    caminho_arquivo = Path(caminho_arquivo)
    caminho_arquivo.parent.mkdir(parents=True, exist_ok=True)
    
    if len(tabela) == 0:
        logger.warning(f"Nenhum dado para salvar em '{caminho_arquivo}'")
        return
    
    logger.info(f"Salvando {len(tabela):,} linhas em arquivo Parquet '{caminho_arquivo}'...")
    pq.write_table(tabela, str(caminho_arquivo), compression='snappy')
    logger.success(f"Arquivo Parquet salvo com {len(tabela):,} linhas.")


def limpar_pasta_temp(caminho_pasta_temp):
    """
    Remove todos os arquivos e subpastas dentro da pasta temp e depois remove a pasta.
    
    Args:
        caminho_pasta_temp: Caminho para a pasta temp (str ou Path)
    """
    caminho_pasta_temp = Path(caminho_pasta_temp)
    
    if not caminho_pasta_temp.exists():
        logger.warning(f"Pasta '{caminho_pasta_temp}' não existe. Nada para limpar.")
        return
    
    try:
        if caminho_pasta_temp.is_dir():
            logger.info(f"Limpando pasta '{caminho_pasta_temp}'...")
            shutil.rmtree(caminho_pasta_temp)
            logger.success(f"Pasta '{caminho_pasta_temp}' removida com sucesso.")
        else:
            logger.warning(f"'{caminho_pasta_temp}' não é uma pasta.")
    except Exception as e:
        logger.error(f"Erro ao limpar pasta '{caminho_pasta_temp}': {e}")
        raise


def fazer_cruzamento(
    caminho_csv, 
    lista_caminhos_parquet, 
    parquet_nao_correspondentes
):
    """
    Faz o cruzamento entre CSV e múltiplos arquivos Parquet usando cnpj_raiz como chave.
    Compara os cnpj_raiz do CSV com os valores dos Parquets.
    Salva apenas os não correspondentes em arquivo Parquet.
    
    Args:
        caminho_csv: Caminho para o arquivo CSV
        lista_caminhos_parquet: Lista de caminhos para arquivos Parquet (list de str ou Path)
        parquet_nao_correspondentes: Caminho para salvar Parquet com não correspondentes (não encontrados nos Parquets)
    """
    logger.info("=" * 60)
    logger.info("INICIANDO PROCESSO DE CRUZAMENTO")
    logger.info("=" * 60)
    

    if isinstance(lista_caminhos_parquet, (str, Path)):
        lista_caminhos_parquet = [lista_caminhos_parquet]
    
    logger.info(f"[1/4] Lendo arquivo CSV...")

    tabela_csv = ler_csv_otimizado(caminho_csv, delimiter=';', tem_cabecalho=False)
    logger.info(f"Total de linhas no CSV: {len(tabela_csv):,}")
    logger.info(f"Colunas disponíveis: {', '.join(tabela_csv.column_names)}")


    coluna_cnpj_raiz = tabela_csv.column(0)
    
    # Garantir que a primeira coluna seja string para preservar zeros à esquerda
    if not pa.types.is_string(coluna_cnpj_raiz.type):
        coluna_cnpj_raiz = coluna_cnpj_raiz.cast(pa.string())
        # Atualizar a tabela com a coluna convertida
        colunas = list(tabela_csv.columns)
        colunas[0] = coluna_cnpj_raiz
        tabela_csv = pa.table(colunas, names=tabela_csv.column_names)

    cnpj_raiz_csv_lista = coluna_cnpj_raiz.to_pylist()

    cnpj_raiz_csv_set = set()
    total_cnpjs_processados = 0
    for valor in cnpj_raiz_csv_lista:
        if valor is not None:
            # Manter como string para preservar zeros à esquerda
            valor_str = str(valor).strip()
            if valor_str:  # Só adicionar se não for string vazia
                cnpj_raiz_csv_set.add(valor_str)
                total_cnpjs_processados += 1
    
    logger.info(f"Total de CNPJs raiz processados no CSV: {total_cnpjs_processados:,} (valores distintos: {len(cnpj_raiz_csv_set):,})")
    
    logger.info(f"[2/4] Extraindo CNPJs raiz de {len(lista_caminhos_parquet)} arquivo(s) Parquet...")
    cnpj_raiz_parquet = extrair_cnpj_raiz_multiplos_parquets(lista_caminhos_parquet)
    
    logger.info("[3/4] Fazendo cruzamento (comparando CSV com Parquets)...")

    indices_correspondentes = []
    indices_nao_correspondentes = []
    
    for i, cnpj_raiz_valor in enumerate(cnpj_raiz_csv_lista):
        if cnpj_raiz_valor is not None:
            # Manter como string para preservar zeros à esquerda
            cnpj_raiz_str = str(cnpj_raiz_valor).strip()
            if cnpj_raiz_str and cnpj_raiz_str in cnpj_raiz_parquet:
                indices_correspondentes.append(i)
            else:
                indices_nao_correspondentes.append(i)
        else:
            indices_nao_correspondentes.append(i)
    
    logger.info(f"Correspondentes encontrados: {len(indices_correspondentes):,} (CNPJs do CSV que existem nos Parquets)")
    logger.info(f"Não correspondentes: {len(indices_nao_correspondentes):,} (CNPJs do CSV que NÃO existem nos Parquets)")

    logger.info("[4/4] Salvando resultados em arquivo Parquet...")
    if indices_nao_correspondentes:
        tabela_nao_correspondentes = tabela_csv.take(pa.array(indices_nao_correspondentes))
        caminho_nao_correspondentes = Path(parquet_nao_correspondentes)
        caminho_nao_correspondentes.parent.mkdir(parents=True, exist_ok=True)
        logger.info(f"Salvando não correspondentes em '{caminho_nao_correspondentes}'...")
        salvar_parquet_nao_correspondentes(tabela_nao_correspondentes, str(caminho_nao_correspondentes))
        logger.success(f"Arquivo Parquet salvo com {len(tabela_nao_correspondentes):,} linhas.")
    else:
        logger.warning(f"Nenhum não correspondente encontrado. Arquivo '{parquet_nao_correspondentes}' não será criado.")
    
    logger.info("=" * 60)
    logger.success("PROCESSO CONCLUÍDO COM SUCESSO!")
    logger.info("=" * 60)


# if __name__ == '__main__':

#     script_dir = Path(__file__).parent.resolve()
#     base_dir = script_dir.parent.parent
    
#     pasta = "03-2025"
    

#     pasta_exportados = script_dir / "exportados"
#     lista_parquets = sorted(pasta_exportados.glob("*.parquet"))
    
#     if not lista_parquets:
#         logger.error(f"Nenhum arquivo Parquet encontrado na pasta '{pasta_exportados}'")
#         raise FileNotFoundError(f"Nenhum arquivo Parquet encontrado na pasta '{pasta_exportados}'")
    
#     logger.info(f"Encontrados {len(lista_parquets)} arquivo(s) Parquet na pasta 'exportados'")
    

#     pasta_temp = script_dir / "temp"
#     arquivos_temp = list(pasta_temp.glob("*"))
#     arquivos_csv_temp = [f for f in arquivos_temp if f.is_file() and not f.name.startswith('.')]
    
#     if not arquivos_csv_temp:
#         logger.error(f"Nenhum arquivo encontrado na pasta '{pasta_temp}'")
#         raise FileNotFoundError(f"Nenhum arquivo encontrado na pasta '{pasta_temp}'")
    
#     if len(arquivos_csv_temp) > 1:
#         logger.warning(f"Múltiplos arquivos encontrados na pasta temp. Usando o primeiro: {arquivos_csv_temp[0].name}")
    
#     file_csv = arquivos_csv_temp[0]
#     logger.info(f"Usando arquivo CSV: {file_csv.name}")

#     parquet_correspondentes = script_dir / "correspondentes.parquet"
#     parquet_nao_correspondentes = script_dir / "nao_correspondentes.parquet"
    
#     try:
#         fazer_cruzamento(
#             str(file_csv),
#             [str(p) for p in lista_parquets],
#             str(parquet_correspondentes),
#             str(parquet_nao_correspondentes)
#         )
#     finally:

#         logger.info("=" * 60)
#         logger.info("LIMPANDO PASTA TEMP...")
#         logger.info("=" * 60)
#         limpar_pasta_temp(pasta_temp)
