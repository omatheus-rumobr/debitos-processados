"""
Script para extrair o conteúdo de simples.zip para a pasta temp.
"""

from pathlib import Path
from zipfile import ZipFile, BadZipFile
from loguru import logger


def extrair_simples_zip(arquivo_zip: str = "simples.zip", pasta_destino: str = "temp") -> bool:
    """
    Extrai o conteúdo de simples.zip para a pasta temp.
    
    Args:
        arquivo_zip: Caminho para o arquivo ZIP (padrão: simples.zip)
        pasta_destino: Pasta de destino para extração (padrão: temp)
        
    Returns:
        True se sucesso, False caso contrário
    """
    logger.info(f"Extraindo {arquivo_zip} para {pasta_destino}...")
    
    zip_path = Path(arquivo_zip)
    if not zip_path.exists():
        logger.error(f"Arquivo {arquivo_zip} não encontrado!")
        return False

    destino_path = Path(pasta_destino)
    destino_path.mkdir(parents=True, exist_ok=True)
    logger.info(f"Pasta de destino criada/verificada: {destino_path}")
    
    try:
        with ZipFile(zip_path, 'r') as zip_ref:
            arquivos = zip_ref.namelist()
            logger.info(f"Arquivos encontrados no ZIP: {len(arquivos)}")
            

            zip_ref.extractall(destino_path)
            
            logger.info(f"✓ Extração concluída!")
            logger.info(f"  Arquivos extraídos para: {destino_path.absolute()}")
            

            for arquivo in arquivos:
                logger.info(f"  - {arquivo}")
            
            return True
            
    except BadZipFile:
        logger.error(f"{arquivo_zip} não é um arquivo ZIP válido!")
        return False
    except Exception as e:
        logger.exception(f"Erro ao extrair ZIP: {e}")
        return False


def main():
    """Função principal."""
    logger.info("=" * 70)
    logger.info("EXTRATOR DE ARQUIVO ZIP")
    logger.info("=" * 70)
    
    sucesso = extrair_simples_zip()
    
    if sucesso:
        logger.info("=" * 70)
        logger.info("✓ EXTRAÇÃO CONCLUÍDA COM SUCESSO!")
        logger.info("=" * 70)
    else:
        logger.error("=" * 70)
        logger.error("✗ EXTRAÇÃO FALHOU!")
        logger.error("=" * 70)
