from datetime import datetime
from loguru import logger
from pathlib import Path
from tqdm import tqdm
import argparse
import requests
import zipfile


def baixar_arquivo(url, nome_arquivo = None, max_tentativas = 3):
    """
    Baixa um arquivo de forma robusta com retry automático e validação.
    
    Args:
        url: URL do arquivo para download
        nome_arquivo: Nome do arquivo de destino (opcional)
        max_tentativas: Número máximo de tentativas em caso de falha
    
    Returns:
        Caminho do arquivo baixado ou None se o período não existir (404)
    """
    logger.debug(f"Iniciando download. URL: {url}, max_tentativas: {max_tentativas}")
    
    if nome_arquivo is None:
        nome_arquivo = url.split('/')[-1]
        logger.debug(f"Nome do arquivo não especificado. Usando: {nome_arquivo}")
    
    diretorio_destino = Path(nome_arquivo).parent
    if not diretorio_destino.exists():
        logger.info(f"Criando diretório de destino: {diretorio_destino.absolute()}")
    diretorio_destino.mkdir(parents=True, exist_ok=True)
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    for tentativa in range(1, max_tentativas + 1):
        try:
            logger.info(f"Tentativa {tentativa}/{max_tentativas}: Baixando {nome_arquivo}...")
            
            response = requests.get(url, headers=headers, stream=True, timeout=30)
            response.raise_for_status()
            tamanho_total = int(response.headers.get('content-length', 0))
            if tamanho_total > 0:
                logger.debug(f"Resposta HTTP recebida. Status: {response.status_code}, Tamanho: {tamanho_total / (1024*1024):.2f} MB")
            else:
                logger.debug(f"Resposta HTTP recebida. Status: {response.status_code}, Tamanho: desconhecido")

            logger.debug(f"Iniciando escrita do arquivo: {nome_arquivo}")
            with open(nome_arquivo, 'wb') as arquivo:
                if tamanho_total > 0:
                    logger.debug(f"Download com barra de progresso. Tamanho total: {tamanho_total / (1024*1024):.2f} MB")
                    with tqdm(total=tamanho_total, unit='B', unit_scale=True, unit_divisor=1024, desc=nome_arquivo) as pbar:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                arquivo.write(chunk)
                                pbar.update(len(chunk))
                else:
                    logger.debug("Download sem informação de tamanho. Progresso não disponível.")
                    bytes_escritos = 0
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            arquivo.write(chunk)
                            bytes_escritos += len(chunk)
                    logger.debug(f"Total de bytes escritos: {bytes_escritos / (1024*1024):.2f} MB")
            
            logger.info(f"Validando integridade do arquivo {nome_arquivo}...")
            if not validar_zip(nome_arquivo):
                logger.warning(f"Arquivo ZIP corrompido. Tentando novamente...")
                Path(nome_arquivo).unlink()
                logger.debug(f"Arquivo corrompido removido: {nome_arquivo}")
                continue
            
            tamanho_arquivo = Path(nome_arquivo).stat().st_size
            logger.success(f"Download concluído com sucesso! Tamanho: {tamanho_arquivo / (1024*1024):.2f} MB")
            logger.debug(f"Arquivo salvo em: {Path(nome_arquivo).absolute()}")
            return nome_arquivo
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                periodo = url.split('?path=/')[1].split('/')[0] if '?path=/' in url else "especificado"
                logger.error(f"O período {periodo} ainda não existe ou o arquivo não está disponível.")
                return None

            logger.error(f"Erro HTTP {e.response.status_code} na tentativa {tentativa}: {e}")
            if tentativa < max_tentativas:
                logger.info("Tentando novamente...")
                caminho_arquivo = Path(nome_arquivo)
                if caminho_arquivo.exists():
                    logger.debug(f"Removendo arquivo parcial antes de nova tentativa: {nome_arquivo}")
                    caminho_arquivo.unlink()
            else:
                logger.error(f"Todas as {max_tentativas} tentativas falharam. Abortando download.")
                raise Exception(f"Falha ao baixar após {max_tentativas} tentativas: {e}")
        except requests.exceptions.RequestException as e:
            logger.error(f"Erro na tentativa {tentativa}: {e}")
            logger.debug(f"Tipo de exceção: {type(e).__name__}")
            if tentativa < max_tentativas:
                logger.info("Tentando novamente...")
                caminho_arquivo = Path(nome_arquivo)
                if caminho_arquivo.exists():
                    logger.debug(f"Removendo arquivo parcial antes de nova tentativa: {nome_arquivo}")
                    caminho_arquivo.unlink()
            else:
                logger.error(f"Todas as {max_tentativas} tentativas falharam. Abortando download.")
                raise Exception(f"Falha ao baixar após {max_tentativas} tentativas: {e}")
    
    logger.error("Loop de tentativas esgotado sem sucesso.")
    raise Exception("Falha no download")


def validar_zip(caminho_arquivo):
    """
    Valida se o arquivo ZIP está íntegro tentando abri-lo.
    
    Args:
        caminho_arquivo: Caminho do arquivo ZIP
    
    Returns:
        True se o arquivo está íntegro, False caso contrário
    """
    logger.debug(f"Iniciando validação do arquivo ZIP: {caminho_arquivo}")
    try:
        tamanho_arquivo = Path(caminho_arquivo).stat().st_size
        logger.debug(f"Tamanho do arquivo: {tamanho_arquivo / (1024*1024):.2f} MB")
        
        with zipfile.ZipFile(caminho_arquivo, 'r') as zip_ref:
            arquivos_no_zip = zip_ref.namelist()
            logger.debug(f"Arquivo ZIP contém {len(arquivos_no_zip)} arquivo(s)")
            resultado_teste = zip_ref.testzip()
            
            if resultado_teste is None:
                logger.debug("Validação do ZIP concluída com sucesso. Arquivo íntegro.")
                return True
            else:
                logger.warning(f"Arquivo corrompido detectado: {resultado_teste}")
                return False
    except zipfile.BadZipFile as e:
        logger.error(f"Arquivo não é um ZIP válido: {e}")
        return False
    except zipfile.LargeZipFile as e:
        logger.error(f"Arquivo ZIP muito grande (requer ZIP64): {e}")
        return False
    except Exception as e:
        logger.error(f"Erro inesperado na validação: {type(e).__name__}: {e}")
        return False


def construir_url(periodo = None):
    """
    Constrói a URL do arquivo Simples.zip com base no período especificado.
    
    Args:
        periodo: Período no formato YYYY-MM (ex: "2025-12"). Se None, usa o período atual.
    
    Returns:
        URL completa do arquivo
    """
    logger.debug(f"Construindo URL. Período fornecido: {periodo}")
    
    if periodo is None:
        agora = datetime.now()
        periodo = agora.strftime("%Y-%m")
        logger.info(f"Período não especificado. Usando período atual: {periodo}")
    else:
        logger.debug(f"Validando formato do período: {periodo}")
        try:
            datetime.strptime(periodo, "%Y-%m")
            logger.debug(f"Período válido: {periodo}")
        except ValueError:
            logger.error(f"Formato de período inválido: {periodo}")
            raise ValueError(f"Período inválido: {periodo}. Use o formato YYYY-MM (ex: 2025-12)")
    
    base_url = "https://arquivos.receitafederal.gov.br/index.php/s/YggdBLfdninEJX9/download?path="
    url_final = f"{base_url}/{periodo}/Simples.zip"
    logger.debug(f"URL construída: {url_final}")
    return url_final


# if __name__ == "__main__":
#     logger.remove()
#     logger.add(
#         lambda msg: print(msg, end=""),
#         format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>",
#         level="INFO"
#     )
#     logger.add(
#         "logs/baixar_{time:YYYY-MM-DD}.log",
#         rotation="00:00",
#         retention="30 days",
#         format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
#         level="DEBUG",
#         encoding="utf-8"
#     )
    
#     parser = argparse.ArgumentParser(
#         description="Baixa o arquivo Simples.zip da Receita Federal para um período específico."
#     )
#     parser.add_argument(
#         "-p", "--periodo",
#         type=str,
#         default=None,
#         help="Período no formato YYYY-MM (ex: 2025-12). Se não especificado, usa o período atual."
#     )
#     parser.add_argument(
#         "-c", "--caminho",
#         type=str,
#         default=None,
#         help="Caminho onde o arquivo será salvo. Se não especificado, usa o diretório atual."
#     )
    
#     args = parser.parse_args()
    
#     try:
#         link = construir_url(args.periodo)
#         periodo_usado = args.periodo if args.periodo else datetime.now().strftime("%Y-%m")
        

#         nome_arquivo_base = f"Simples-{periodo_usado}.zip"
#         logger.info(nome_arquivo_base)
#         if args.caminho:
#             caminho_destino = Path(args.caminho)
#             caminho_destino.mkdir(parents=True, exist_ok=True)
#             nome_arquivo = caminho_destino / nome_arquivo_base
#         else:
#             nome_arquivo = Path(nome_arquivo_base)
        
#         logger.info(f"Baixando arquivo para o período: {periodo_usado}")
        
#         arquivo_baixado = baixar_arquivo(link, nome_arquivo=nome_arquivo)
#         if arquivo_baixado:
#             logger.success(f"Arquivo salvo em: {Path(arquivo_baixado).absolute()}")
#         else:
#             logger.warning("Download não foi concluído.")
#     except ValueError as e:
#         logger.error(f"Erro: {e}")
#         exit(1)
