import pyarrow.parquet as pq
import pandas as pd
from pathlib import Path
from datetime import datetime
import gc
import time
from collections import defaultdict
from loguru import logger


def parse_data_brasileira(data_str):
    """
    Converte data no padrão brasileiro (DD/MM/YYYY) para objeto datetime.
    Retorna None se não conseguir converter.
    """
    if data_str is None or data_str == '':
        logger.debug(f"Data vazia ou None recebida: {data_str}")
        return None
    
    try:
        resultado = datetime.strptime(str(data_str), '%d/%m/%Y')
        logger.trace(f"Data convertida com sucesso (formato completo): {data_str} -> {resultado}")
        return resultado
    except (ValueError, TypeError):
        try:
            resultado = datetime.strptime(str(data_str), '%d/%m/%y')
            logger.trace(f"Data convertida com sucesso (formato curto): {data_str} -> {resultado}")
            return resultado
        except (ValueError, TypeError):
            logger.debug(f"Não foi possível converter a data: {data_str}")
            return None


def obter_ano_da_data(data_str):
    """
    Extrai o ano de uma data no formato brasileiro.
    Retorna None se não conseguir extrair.
    """
    data_obj = parse_data_brasileira(data_str)
    if data_obj:
        ano = data_obj.year
        logger.trace(f"Ano extraído: {data_str} -> {ano}")
        return ano
    logger.trace(f"Não foi possível extrair ano de: {data_str}")
    return None


def dividir_parquet_por_ano(arquivo_entrada, diretorio_saida=None):
    """
    Lê um arquivo parquet e separa os dados por ano baseado no campo 'saida'.
    Cria um arquivo parquet para cada ano encontrado.
    
    Args:
        arquivo_entrada: Caminho para o arquivo parquet de entrada
        diretorio_saida: Diretório onde salvar os arquivos separados (padrão: mesmo diretório do arquivo de entrada)
    """
    inicio_total = time.time()
    logger.info("=" * 80)
    logger.info("DIVISÃO DE ARQUIVO PARQUET POR ANO")
    logger.info("=" * 80)

    caminho_entrada = Path(arquivo_entrada)
    if not caminho_entrada.exists():
        logger.error(f"Arquivo não encontrado: {arquivo_entrada}")
        return
    
    logger.info("[CONFIGURAÇÃO]")
    logger.info(f"   Arquivo de entrada: {caminho_entrada}")
    logger.debug(f"   Caminho absoluto: {caminho_entrada.absolute()}")

    if diretorio_saida is None:
        diretorio_saida = caminho_entrada.parent
        logger.debug(f"Diretório de saída não especificado. Usando diretório do arquivo de entrada: {diretorio_saida}")
    else:
        diretorio_saida = Path(diretorio_saida)
        if not diretorio_saida.exists():
            logger.info(f"Criando diretório de saída: {diretorio_saida.absolute()}")
        diretorio_saida.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"   Diretório de saída: {diretorio_saida}")
    logger.info(f"   Campo para extração de ano: 'saida'")
    logger.info(f"   Timestamp início: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    

    try:
        logger.debug(f"Abrindo arquivo parquet: {caminho_entrada}")
        parquet_file = pq.ParquetFile(str(caminho_entrada))
        num_linhas_total = parquet_file.metadata.num_rows
        num_row_groups = parquet_file.metadata.num_row_groups
        schema = parquet_file.schema_arrow
        
        logger.success("Arquivo parquet aberto com sucesso")
        logger.info(f"Total de linhas: {num_linhas_total:,}")
        logger.info(f"Total de row groups: {num_row_groups}")
        logger.debug(f"Schema do arquivo: {len(schema.names)} colunas")

        colunas_parquet = schema.names
        if 'saida' not in colunas_parquet:
            logger.error("Campo 'saida' não encontrado no arquivo parquet.")
            colunas_preview = ', '.join(colunas_parquet[:10])
            if len(colunas_parquet) > 10:
                colunas_preview += '...'
            logger.info(f"Colunas disponíveis: {colunas_preview}")
            logger.debug(f"Total de colunas: {len(colunas_parquet)}")
            return
        
        logger.debug(f"Campo 'saida' encontrado no arquivo")
        
    except Exception as e:
        logger.exception(f"Erro ao abrir arquivo: {e}")
        return
    

    dados_por_ano = defaultdict(list)
    total_registros_processados = 0
    registros_sem_ano = 0
    
    logger.info("Iniciando processamento em lotes...")
    logger.info("-" * 80)

    for row_group_idx in range(num_row_groups):
        inicio_lote = time.time()
        
        try:
            logger.info(f"[LOTE {row_group_idx + 1}/{num_row_groups}] Processando...")

            logger.debug(f"Lendo row group {row_group_idx} do arquivo parquet")
            tabela_lote = parquet_file.read_row_groups([row_group_idx], use_threads=True)
            num_linhas_lote = len(tabela_lote)
            logger.debug(f"Row group {row_group_idx} contém {num_linhas_lote:,} linhas")

            logger.debug(f"Convertendo tabela para pandas DataFrame")
            df_lote = tabela_lote.to_pandas()

            del tabela_lote
            gc.collect()
            logger.trace(f"Memória liberada após conversão do row group {row_group_idx}")

            logger.debug(f"Extraindo anos do campo 'saida' para o lote {row_group_idx + 1}")
            df_lote['_ano_temp'] = df_lote['saida'].apply(obter_ano_da_data)

            registros_sem_ano_lote = df_lote['_ano_temp'].isna().sum()
            registros_sem_ano += registros_sem_ano_lote
            if registros_sem_ano_lote > 0:
                logger.warning(f"Lote {row_group_idx + 1}: {registros_sem_ano_lote:,} registros sem ano válido")

            anos_unicos = df_lote['_ano_temp'].dropna().unique()
            logger.debug(f"Lote {row_group_idx + 1}: Anos encontrados: {sorted(anos_unicos)}")
            
            for ano in anos_unicos:
                if ano is not None:
                    df_ano = df_lote[df_lote['_ano_temp'] == ano].copy()
                    df_ano = df_ano.drop(columns=['_ano_temp'])
                    dados_por_ano[int(ano)].append(df_ano)
                    logger.trace(f"Lote {row_group_idx + 1}: {len(df_ano):,} registros adicionados para o ano {ano}")
            
            total_registros_processados += num_linhas_lote
            tempo_lote = time.time() - inicio_lote
            percentual = (total_registros_processados / num_linhas_total) * 100
            logger.info(f"[LOTE {row_group_idx + 1}/{num_row_groups}] {num_linhas_lote:,} linhas processadas em {tempo_lote:.2f}s ({percentual:.1f}% concluído)")

            del df_lote
            gc.collect()
            logger.trace(f"Memória liberada após processamento do lote {row_group_idx + 1}")
            
        except Exception as e:
            logger.exception(f"Erro ao processar row group {row_group_idx}: {e}")
            continue
    
    logger.info("=" * 80)
    logger.info("Processamento concluído. Consolidando e salvando arquivos...")
    logger.info("=" * 80)

    anos_encontrados = sorted(dados_por_ano.keys())
    logger.info(f"Total de anos únicos encontrados: {len(anos_encontrados)}")
    logger.debug(f"Anos: {anos_encontrados}")
    total_registros_salvos = 0
    
    for ano in anos_encontrados:
        inicio_consolidacao = time.time()
        logger.info(f"[ANO {ano}] Consolidando dados...")
        
        num_dataframes = len(dados_por_ano[ano])
        logger.debug(f"Ano {ano}: Consolidando {num_dataframes} dataframes")

        df_ano_completo = pd.concat(dados_por_ano[ano], ignore_index=True)
        num_registros = len(df_ano_completo)
        logger.debug(f"Ano {ano}: DataFrame consolidado com {num_registros:,} registros")

        nome_arquivo_saida = f"apenas_nao_duplicados_{ano}.parquet"
        caminho_saida = diretorio_saida / nome_arquivo_saida
        logger.debug(f"Ano {ano}: Salvando em {caminho_saida.absolute()}")

        df_ano_completo.to_parquet(
            caminho_saida,
            engine='pyarrow',
            compression='snappy',
            index=False
        )
        
        total_registros_salvos += num_registros
        tempo_consolidacao = time.time() - inicio_consolidacao
        tamanho_mb = caminho_saida.stat().st_size / (1024 * 1024)
        logger.debug(f"Ano {ano}: Arquivo salvo com {tamanho_mb:.2f} MB")

        del df_ano_completo
        del dados_por_ano[ano]
        gc.collect()
        logger.trace(f"Memória liberada após salvar arquivo do ano {ano}")
        
        logger.success(f"[ANO {ano}] {num_registros:,} registros salvos em '{nome_arquivo_saida}' ({tempo_consolidacao:.2f}s)")
    
    tempo_total = time.time() - inicio_total

    logger.info("=" * 80)
    logger.info("RESUMO DA DIVISÃO")
    logger.info("=" * 80)
    logger.info("[RESULTADOS]")
    logger.info(f"   Total de registros processados: {total_registros_processados:,}")
    logger.info(f"   Total de registros salvos: {total_registros_salvos:,}")
    if registros_sem_ano > 0:
        logger.warning(f"   Registros sem ano válido: {registros_sem_ano:,}")
    else:
        logger.info(f"   Registros sem ano válido: {registros_sem_ano:,}")
    logger.info(f"   Anos encontrados: {len(anos_encontrados)}")
    
    logger.info("[ARQUIVOS CRIADOS]")
    tamanho_total_mb = 0
    for ano in anos_encontrados:
        nome_arquivo = f"apenas_nao_duplicados_{ano}.parquet"
        caminho_arquivo = diretorio_saida / nome_arquivo
        tamanho_mb = caminho_arquivo.stat().st_size / (1024 * 1024)
        tamanho_total_mb += tamanho_mb
        logger.info(f"   {nome_arquivo} ({tamanho_mb:.2f} MB)")
    
    logger.info(f"[PERFORMANCE]")
    logger.info(f"   Tempo total: {tempo_total:.2f}s ({tempo_total/60:.2f} minutos)")
    if total_registros_processados > 0:
        registros_por_segundo = total_registros_processados / tempo_total if tempo_total > 0 else 0
        logger.info(f"   Taxa de processamento: {registros_por_segundo:,.0f} registros/segundo")
    logger.debug(f"   Tamanho total dos arquivos gerados: {tamanho_total_mb:.2f} MB")
    logger.info("=" * 80)
    
    logger.success("Divisão concluída com sucesso!")
    logger.info(f"Arquivos salvos em: {diretorio_saida.absolute()}")


def main():
    """Função principal"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Divide arquivo parquet por ano baseado no campo "saida"',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
            Exemplos:
            python divisor.py
            python divisor.py --arquivo apenas_nao_duplicados.parquet
            python divisor.py --arquivo apenas_nao_duplicados.parquet --saida ./anos
        """
    )
    
    parser.add_argument(
        '--arquivo',
        type=str,
        default='apenas_nao_duplicados.parquet',
        help='Caminho para o arquivo parquet de entrada (padrão: apenas_nao_duplicados.parquet)'
    )
    
    parser.add_argument(
        '--saida',
        type=str,
        default=None,
        help='Diretório onde salvar os arquivos separados por ano (padrão: mesmo diretório do arquivo de entrada)'
    )
    
    args = parser.parse_args()
    
    logger.debug(f"Argumentos recebidos: arquivo={args.arquivo}, saida={args.saida}")

    dividir_parquet_por_ano(
        arquivo_entrada=args.arquivo,
        diretorio_saida=args.saida
    )


# if __name__ == "__main__":
#     main()
