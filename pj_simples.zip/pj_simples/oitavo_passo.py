import pyarrow.parquet as pq
from loguru import logger
from pathlib import Path
import pyarrow as pa
import time
import pandas as pd
import gc
import shutil


def encontrar_arquivos_parquet(pasta_raiz):
    """
    Encontra todos os arquivos tabela_unificada.parquet recursivamente.
    
    Args:
        pasta_raiz: Caminho da pasta raiz do projeto
        
    Returns:
        Lista de caminhos para os arquivos encontrados
    """
    pasta_raiz = Path(pasta_raiz)
    arquivos = list(pasta_raiz.rglob("tabela_unificada.parquet"))
    logger.info(f"Encontrados {len(arquivos)} arquivos parquet")
    return arquivos


def ler_parquet_otimizado(caminho_arquivo):
    """
    Lê um arquivo parquet de forma otimizada usando PyArrow.
    
    Args:
        caminho_arquivo: Caminho para o arquivo parquet
        
    Returns:
        pyarrow.Table: Tabela lida do arquivo
    """
    logger.info(f"Lendo arquivo: {caminho_arquivo}")
    
    parquet_file = pq.ParquetFile(caminho_arquivo)
    
    tabela = parquet_file.read()
    
    logger.info(f"Arquivo lido: {caminho_arquivo} - {len(tabela)} linhas")
    return tabela


def combinar_tabelas(lista_tabelas):
    """
    Combina múltiplas tabelas PyArrow em uma única tabela.
    
    Args:
        lista_tabelas: Lista de tabelas PyArrow
        
    Returns:
        pyarrow.Table: Tabela combinada
    """
    if not lista_tabelas:
        logger.warning("Nenhuma tabela para combinar")
        return None
    
    logger.info(f"Combinando {len(lista_tabelas)} tabelas...")
    
    tabela_combinada = pa.concat_tables(lista_tabelas, promote=True)
    
    logger.info(f"Tabela combinada: {len(tabela_combinada)} linhas")
    return tabela_combinada


def identificar_duplicados(tabela, coluna_cnpj_raiz="cnpj_raiz"):
    """
    Identifica duplicados baseado na coluna cnpj_raiz.
    
    Args:
        tabela: pyarrow.Table com os dados
        coluna_cnpj_raiz: Nome da coluna para identificar duplicados
        
    Returns:
        tupla: (tabela_sem_duplicados, tabela_duplicados, tabela_nao_duplicados)
    """
    logger.info("Identificando duplicados...")
    

    import pandas as pd
    
    df = tabela.to_pandas()
    

    if coluna_cnpj_raiz not in df.columns:
        logger.error(f"Coluna '{coluna_cnpj_raiz}' não encontrada nas colunas: {df.columns.tolist()}")
        raise ValueError(f"Coluna '{coluna_cnpj_raiz}' não encontrada")
    

    duplicados_mask = df.duplicated(subset=[coluna_cnpj_raiz], keep=False)
    

    df_sem_duplicados = df.drop_duplicates(subset=[coluna_cnpj_raiz], keep='first')
    

    df_duplicados = df[duplicados_mask]
    

    df_nao_duplicados = df[~duplicados_mask]
    
    logger.info(f"Total de linhas: {len(df)}")
    logger.info(f"Linhas sem duplicados (único por cnpj_raiz): {len(df_sem_duplicados)}")
    logger.info(f"Linhas duplicadas: {len(df_duplicados)}")
    logger.info(f"Linhas não duplicadas (únicas): {len(df_nao_duplicados)}")
    

    tabela_sem_duplicados = pa.Table.from_pandas(df_sem_duplicados)
    tabela_duplicados = pa.Table.from_pandas(df_duplicados)
    tabela_nao_duplicados = pa.Table.from_pandas(df_nao_duplicados)
    
    return tabela_sem_duplicados, tabela_duplicados, tabela_nao_duplicados


def salvar_parquet(tabela, caminho_saida):
    """
    Salva uma tabela PyArrow como arquivo parquet de forma otimizada.
    
    Args:
        tabela: pyarrow.Table para salvar
        caminho_saida: Caminho do arquivo de saída
    """
    logger.info(f"Salvando arquivo: {caminho_saida} ({len(tabela)} linhas)")
    

    pq.write_table(
        tabela,
        caminho_saida,
        compression='snappy',
        use_dictionary=True,
        write_statistics=True,
        row_group_size=100000
    )
    
    logger.info(f"Arquivo salvo: {caminho_saida}")


def processar_arquivo_individual(arquivo, pasta_temp, coluna_cnpj_raiz="cnpj_raiz"):
    """
    Processa um arquivo individual, identifica duplicados locais e salva resultados parciais.
    
    Args:
        arquivo: Caminho do arquivo parquet a processar
        pasta_temp: Pasta para salvar arquivos temporários
        coluna_cnpj_raiz: Nome da coluna para identificar duplicados
        
    Returns:
        dict: Estatísticas do processamento (total, duplicados, não_duplicados)
    """
    logger.info(f"\nProcessando arquivo: {arquivo}")
    

    tabela = ler_parquet_otimizado(arquivo)
    

    df = tabela.to_pandas()
    

    del tabela
    gc.collect()
    

    if coluna_cnpj_raiz not in df.columns:
        logger.error(f"Coluna '{coluna_cnpj_raiz}' não encontrada")
        raise ValueError(f"Coluna '{coluna_cnpj_raiz}' não encontrada")
    

    duplicados_mask = df.duplicated(subset=[coluna_cnpj_raiz], keep=False)
    df_sem_duplicados = df.drop_duplicates(subset=[coluna_cnpj_raiz], keep='first')
    df_duplicados = df[duplicados_mask]
    df_nao_duplicados = df[~duplicados_mask]
    

    pasta_temp.mkdir(parents=True, exist_ok=True)
    

    nome_base = arquivo.stem
    

    if len(df_sem_duplicados) > 0:
        tabela_temp = pa.Table.from_pandas(df_sem_duplicados)
        salvar_parquet(
            tabela_temp,
            pasta_temp / f"{nome_base}_sem_duplicados_temp.parquet"
        )
        del tabela_temp
    
    if len(df_duplicados) > 0:
        tabela_temp = pa.Table.from_pandas(df_duplicados)
        salvar_parquet(
            tabela_temp,
            pasta_temp / f"{nome_base}_duplicados_temp.parquet"
        )
        del tabela_temp
    
    if len(df_nao_duplicados) > 0:
        tabela_temp = pa.Table.from_pandas(df_nao_duplicados)
        salvar_parquet(
            tabela_temp,
            pasta_temp / f"{nome_base}_nao_duplicados_temp.parquet"
        )
        del tabela_temp

    stats = {
        'total': len(df),
        'duplicados': len(df_duplicados),
        'nao_duplicados': len(df_nao_duplicados)
    }
    

    del df, df_sem_duplicados, df_duplicados, df_nao_duplicados
    gc.collect()
    
    logger.info(f"Arquivo processado: {stats['total']} linhas")
    
    return stats


def combinar_arquivos_sem_duplicados(pasta_temp, arquivo_final):
    """
    Combina todos os arquivos temporários sem_duplicados e identifica duplicados finais.
    
    Args:
        pasta_temp: Pasta com os arquivos temporários
        arquivo_final: Caminho do arquivo final de saída
    """
    arquivos_temp = list(pasta_temp.glob("*_sem_duplicados_temp.parquet"))
    
    if not arquivos_temp:
        logger.warning("Nenhum arquivo temporário sem_duplicados encontrado")
        return
    
    logger.info(f"Combinando {len(arquivos_temp)} arquivos temporários sem_duplicados...")
    
    tabelas = []
    for arquivo_temp in arquivos_temp:
        try:
            tabela = ler_parquet_otimizado(arquivo_temp)
            tabelas.append(tabela)

            del tabela
            gc.collect()
        except Exception as e:
            logger.error(f"Erro ao ler arquivo temporário {arquivo_temp}: {e}")
            continue
    
    if not tabelas:
        logger.warning("Nenhuma tabela para combinar")
        return
    

    logger.info("Combinando tabelas em memória...")
    tabela_combinada = pa.concat_tables(tabelas, promote=True)
    

    del tabelas
    gc.collect()
    

    logger.info("Identificando duplicados finais entre arquivos...")
    df = tabela_combinada.to_pandas()
    

    del tabela_combinada
    gc.collect()
    

    coluna_cnpj_raiz = "cnpj_raiz"
    duplicados_mask = df.duplicated(subset=[coluna_cnpj_raiz], keep=False)
    df_sem_duplicados = df.drop_duplicates(subset=[coluna_cnpj_raiz], keep='first')
    
    logger.info(f"Total após combinação: {len(df)} linhas")
    logger.info(f"Linhas sem duplicados finais: {len(df_sem_duplicados)}")
    logger.info(f"Duplicados encontrados entre arquivos: {len(df) - len(df_sem_duplicados)}")
    

    if len(df_sem_duplicados) > 0:
        tabela_final = pa.Table.from_pandas(df_sem_duplicados)
        salvar_parquet(tabela_final, arquivo_final)
        del tabela_final
    

    del df, df_sem_duplicados
    gc.collect()
    
    logger.info(f"Arquivo final salvo: {arquivo_final}")


def processar_duplicados_finais(pasta_temp, pasta_raiz):
    """
    Processa os arquivos temporários de duplicados e não duplicados para gerar os arquivos finais.
    
    Args:
        pasta_temp: Pasta com os arquivos temporários
        pasta_raiz: Pasta raiz para salvar arquivos finais
    """

    arquivos_duplicados = list(pasta_temp.glob("*_duplicados_temp.parquet"))
    if arquivos_duplicados:
        logger.info(f"Combinando {len(arquivos_duplicados)} arquivos de duplicados...")
        tabelas_dup = []
        for arquivo in arquivos_duplicados:
            tabela = ler_parquet_otimizado(arquivo)
            tabelas_dup.append(tabela)
            del tabela
            gc.collect()
        
        if tabelas_dup:
            tabela_combinada = pa.concat_tables(tabelas_dup, promote=True)
            del tabelas_dup
            gc.collect()
            salvar_parquet(tabela_combinada, pasta_raiz / "apenas_duplicados.parquet")
            del tabela_combinada
            gc.collect()
    

    arquivos_nao_duplicados = list(pasta_temp.glob("*_nao_duplicados_temp.parquet"))
    if arquivos_nao_duplicados:
        logger.info(f"Combinando {len(arquivos_nao_duplicados)} arquivos de não duplicados...")
        tabelas_ndup = []
        for arquivo in arquivos_nao_duplicados:
            tabela = ler_parquet_otimizado(arquivo)
            tabelas_ndup.append(tabela)
            del tabela
            gc.collect()
        
        if tabelas_ndup:
            tabela_combinada = pa.concat_tables(tabelas_ndup, promote=True)
            del tabelas_ndup
            gc.collect()
            salvar_parquet(tabela_combinada, pasta_raiz / "apenas_nao_duplicados.parquet")
            del tabela_combinada
            gc.collect()


def main():
    """
    Função principal que executa todo o processo de forma otimizada em memória.
    Processa um arquivo por vez para evitar estouro de memória.
    """
    inicio = time.time()
    

    pasta_raiz = Path(__file__).parent
    pasta_temp = pasta_raiz / "temp_processamento"
    
    logger.info("=" * 60)
    logger.info("Iniciando processamento de arquivos parquet (modo otimizado)")
    logger.info("=" * 60)
    

    arquivos = encontrar_arquivos_parquet(pasta_raiz)
    
    if not arquivos:
        logger.error("Nenhum arquivo tabela_unificada.parquet encontrado!")
        return
    

    if pasta_temp.exists():
        logger.info("Limpando pasta temporária anterior...")
        shutil.rmtree(pasta_temp)
    pasta_temp.mkdir(parents=True, exist_ok=True)
    

    logger.info("\n" + "=" * 60)
    logger.info("Processando arquivos individualmente...")
    logger.info("=" * 60)
    
    stats_totais = {'total': 0, 'duplicados': 0, 'nao_duplicados': 0}
    
    for i, arquivo in enumerate(arquivos, 1):
        logger.info(f"\n[{i}/{len(arquivos)}] Processando arquivo...")
        try:
            stats = processar_arquivo_individual(arquivo, pasta_temp)
            stats_totais['total'] += stats['total']
            stats_totais['duplicados'] += stats['duplicados']
            stats_totais['nao_duplicados'] += stats['nao_duplicados']
        except Exception as e:
            logger.error(f"Erro ao processar {arquivo}: {e}")
            continue
    
    logger.info("\n" + "=" * 60)
    logger.info("Estatísticas do processamento individual:")
    logger.info(f"  Total de linhas processadas: {stats_totais['total']}")
    logger.info(f"  Linhas duplicadas (local): {stats_totais['duplicados']}")
    logger.info(f"  Linhas não duplicadas (local): {stats_totais['nao_duplicados']}")
    logger.info("=" * 60)
    

    logger.info("\n" + "=" * 60)
    logger.info("Combinando resultados e identificando duplicados finais...")
    logger.info("=" * 60)
    

    combinar_arquivos_sem_duplicados(
        pasta_temp,
        pasta_raiz / "todos_dados_sem_duplicacoes.parquet"
    )
    

    processar_duplicados_finais(pasta_temp, pasta_raiz)
    

    logger.info("\n" + "=" * 60)
    logger.info("Limpando arquivos temporários...")
    logger.info("=" * 60)
    
    try:
        shutil.rmtree(pasta_temp)
        logger.info("Arquivos temporários removidos com sucesso")
    except Exception as e:
        logger.warning(f"Erro ao remover arquivos temporários: {e}")
    
    tempo_total = time.time() - inicio
    logger.info("\n" + "=" * 60)
    logger.info(f"Processamento concluído em {tempo_total:.2f} segundos")
    logger.info("=" * 60)
    logger.info(f"Arquivos gerados:")
    logger.info(f"  1. todos_dados_sem_duplicacoes.parquet")
    logger.info(f"  2. apenas_duplicados.parquet")
    logger.info(f"  3. apenas_nao_duplicados.parquet")
    logger.info("=" * 60)


# if __name__ == "__main__":
#     main()
